import React, { useState } from 'react';
import { ZtnaProvider, useZtna } from './context/ZtnaContext';
import { Navbar, NavTab } from './components/Navbar';
import { ApplicationsTab } from './components/tabs/ApplicationsTab';
import { PoliciesTab } from './components/tabs/PoliciesTab';
import { DevicePostureTab } from './components/tabs/DevicePostureTab';
import { TrafficAuditTab } from './components/tabs/TrafficAuditTab';
import { GatewaysTab } from './components/tabs/GatewaysTab';
import { VpnMigrationTab } from './components/tabs/VpnMigrationTab';
import { ClientDaemonModal } from './components/ClientDaemonModal';
import { PolicyEvaluatorModal } from './components/PolicyEvaluatorModal';
import { JitAccessModal } from './components/JitAccessModal';
import { AppDetailModal } from './components/AppDetailModal';
import { DeviceDetailModal } from './components/DeviceDetailModal';
import { PolicyEditorModal } from './components/PolicyEditorModal';
import { AddResourceModal } from './components/AddResourceModal';
import { ApplicationResource, AccessPolicy, DevicePosture } from './types/ztna';

const MainLayout: React.FC = () => {
  const [activeTab, setActiveTab] = useState<NavTab>('apps');
  const [selectedApp, setSelectedApp] = useState<ApplicationResource | null>(null);
  const [selectedDevice, setSelectedDevice] = useState<DevicePosture | null>(null);
  const [editingPolicy, setEditingPolicy] = useState<AccessPolicy | null>(null);
  const [isCreatingPolicy, setIsCreatingPolicy] = useState<boolean>(false);
  const [isAddingApp, setIsAddingApp] = useState<boolean>(false);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Bar Contract Compliant Navigation */}
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Viewport Container */}
      <main className="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'apps' && (
          <ApplicationsTab
            onOpenAppDetail={app => setSelectedApp(app)}
            onOpenAddApp={() => setIsAddingApp(true)}
          />
        )}

        {activeTab === 'policies' && (
          <PoliciesTab
            onOpenCreatePolicy={() => setIsCreatingPolicy(true)}
            onEditPolicy={policy => setEditingPolicy(policy)}
          />
        )}

        {activeTab === 'posture' && (
          <DevicePostureTab
            onOpenDeviceDetail={device => setSelectedDevice(device)}
          />
        )}

        {activeTab === 'traffic' && <TrafficAuditTab />}

        {activeTab === 'gateways' && <GatewaysTab />}

        {activeTab === 'migration' && <VpnMigrationTab />}
      </main>

      {/* Modals & Overlays */}
      <ClientDaemonModal />
      <PolicyEvaluatorModal />
      <JitAccessModal />

      {selectedApp && (
        <AppDetailModal
          app={selectedApp}
          onClose={() => setSelectedApp(null)}
        />
      )}

      {selectedDevice && (
        <DeviceDetailModal
          device={selectedDevice}
          onClose={() => setSelectedDevice(null)}
        />
      )}

      {(isCreatingPolicy || editingPolicy) && (
        <PolicyEditorModal
          policy={editingPolicy}
          onClose={() => {
            setIsCreatingPolicy(false);
            setEditingPolicy(null);
          }}
        />
      )}

      {isAddingApp && (
        <AddResourceModal
          onClose={() => setIsAddingApp(false)}
        />
      )}

      {/* Clean quiet footer */}
      <footer className="border-t border-slate-900 py-6 text-center text-xs text-slate-500">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>Aegis ZTNA Architecture · BeyondCorp & WireGuard-based Zero Trust Control Plane</span>
          <div className="flex items-center gap-3 text-slate-500">
            <span>RFC 3514 Zero Trust Compliant</span>
            <span aria-hidden="true">·</span>
            <span>mTLS / ChaCha20-Poly1305</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <ZtnaProvider>
      <MainLayout />
    </ZtnaProvider>
  );
}
