import React, { useState } from 'react';
import { useZtna } from '../context/ZtnaContext';
import { DevicePosture } from '../types/ztna';
import {
  X,
  Laptop,
  Shield,
  ShieldCheck,
  ShieldAlert,
  Flame,
  HardDrive,
  Cpu,
  Clock,
  MapPin,
  RefreshCw,
  Ban,
  CheckCircle2
} from 'lucide-react';

interface DeviceDetailModalProps {
  device: DevicePosture;
  onClose: () => void;
}

export const DeviceDetailModal: React.FC<DeviceDetailModalProps> = ({ device, onClose }) => {
  const { quarantineDevice, unquarantineDevice, triggerDeviceScan } = useZtna();
  const [quarantineReasonInput, setQuarantineReasonInput] = useState('');
  const [showQuarantinePrompt, setShowQuarantinePrompt] = useState(false);

  const handleQuarantine = () => {
    quarantineDevice(device.id, quarantineReasonInput || 'Administrative security quarantine');
    setShowQuarantinePrompt(false);
  };

  const handleScan = () => {
    triggerDeviceScan(device.id);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
      <div className="w-full max-w-2xl rounded-lg border border-slate-800 bg-slate-900 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 px-5 py-3.5 bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded bg-slate-800 text-cyan-400">
              <Laptop className="h-4 w-4" />
            </div>
            <div>
              <div className="text-sm font-semibold text-white">{device.deviceName}</div>
              <div className="text-xs text-slate-400">
                {device.userName} · {device.userEmail}
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded p-1 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Content */}
        <div className="overflow-y-auto p-5 space-y-4">
          {/* Posture status banner */}
          <div
            className={`p-3.5 rounded-lg border flex items-center justify-between ${
              device.trustLevel === 'compliant'
                ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-200'
                : device.trustLevel === 'warning'
                ? 'border-amber-500/30 bg-amber-500/10 text-amber-200'
                : 'border-rose-500/30 bg-rose-500/10 text-rose-200'
            }`}
          >
            <div className="flex items-center gap-2.5">
              {device.trustLevel === 'compliant' && (
                <ShieldCheck className="h-5 w-5 text-emerald-400" />
              )}
              {device.trustLevel === 'warning' && (
                <ShieldAlert className="h-5 w-5 text-amber-400" />
              )}
              {device.trustLevel === 'quarantined' && (
                <ShieldAlert className="h-5 w-5 text-rose-400" />
              )}
              <div>
                <div className="text-xs font-semibold uppercase tracking-wider">
                  Posture Status: {device.trustLevel}
                </div>
                {device.quarantineReason && (
                  <div className="text-xs text-slate-300 mt-0.5">
                    {device.quarantineReason}
                  </div>
                )}
              </div>
            </div>

            <button
              onClick={handleScan}
              className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded bg-slate-800/80 hover:bg-slate-800 text-slate-200 border border-slate-700 transition-colors"
            >
              <RefreshCw className="h-3 w-3" />
              <span>Re-scan Posture</span>
            </button>
          </div>

          {/* Telemetry Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            <div className="p-3 rounded border border-slate-800 bg-slate-950/40">
              <div className="text-xs text-slate-400">OS Build</div>
              <div className="text-xs font-semibold text-slate-200 mt-1">
                {device.osType} {device.osVersion}
              </div>
            </div>

            <div className="p-3 rounded border border-slate-800 bg-slate-950/40">
              <div className="text-xs text-slate-400">Virtual WireGuard IP</div>
              <div className="text-xs font-mono font-semibold text-cyan-300 mt-1 tabular-nums">
                {device.virtualIp}
              </div>
            </div>

            <div className="p-3 rounded border border-slate-800 bg-slate-950/40">
              <div className="text-xs text-slate-400">Hardware Serial</div>
              <div className="text-xs font-mono text-slate-300 mt-1">
                {device.serialNumber}
              </div>
            </div>

            <div className="p-3 rounded border border-slate-800 bg-slate-950/40">
              <div className="text-xs text-slate-400 flex items-center gap-1">
                <Cpu className="h-3 w-3 text-cyan-400" /> Hardware Enclave / TPM
              </div>
              <div className="text-xs font-semibold mt-1">
                {device.tpmEnclaveEnabled ? (
                  <span className="text-emerald-400">TPM 2.0 / Enclave Active</span>
                ) : (
                  <span className="text-rose-400">Not Present</span>
                )}
              </div>
            </div>

            <div className="p-3 rounded border border-slate-800 bg-slate-950/40">
              <div className="text-xs text-slate-400 flex items-center gap-1">
                <HardDrive className="h-3 w-3 text-indigo-400" /> Disk Encryption
              </div>
              <div className="text-xs font-semibold mt-1 capitalize">
                {device.diskEncryption === 'encrypted' ? (
                  <span className="text-emerald-400">Encrypted (FileVault/BitLocker)</span>
                ) : (
                  <span className="text-rose-400">Disabled / Unencrypted</span>
                )}
              </div>
            </div>

            <div className="p-3 rounded border border-slate-800 bg-slate-950/40">
              <div className="text-xs text-slate-400 flex items-center gap-1">
                <Shield className="h-3 w-3 text-amber-400" /> EDR Sensor
              </div>
              <div className="text-xs font-semibold mt-1">
                <span className={device.edrStatus === 'running' ? 'text-emerald-400' : 'text-rose-400'}>
                  {device.edrAgent.toUpperCase()} ({device.edrStatus})
                </span>
              </div>
            </div>

            <div className="p-3 rounded border border-slate-800 bg-slate-950/40">
              <div className="text-xs text-slate-400 flex items-center gap-1">
                <Flame className="h-3 w-3 text-rose-400" /> Host OS Firewall
              </div>
              <div className="text-xs font-semibold mt-1">
                {device.firewallActive ? (
                  <span className="text-emerald-400">Enforced & Active</span>
                ) : (
                  <span className="text-rose-400">Disabled by User</span>
                )}
              </div>
            </div>

            <div className="p-3 rounded border border-slate-800 bg-slate-950/40">
              <div className="text-xs text-slate-400 flex items-center gap-1">
                <Clock className="h-3 w-3 text-slate-400" /> Screen Lock Timeout
              </div>
              <div className="text-xs font-semibold text-slate-200 mt-1">
                {device.screenLockTimeoutMin} minutes
              </div>
            </div>

            <div className="p-3 rounded border border-slate-800 bg-slate-950/40">
              <div className="text-xs text-slate-400 flex items-center gap-1">
                <MapPin className="h-3 w-3 text-cyan-400" /> Geolocation
              </div>
              <div className="text-xs font-semibold text-slate-200 mt-1">
                {device.geolocation.city}, {device.geolocation.country}
              </div>
            </div>
          </div>

          {/* Quarantine modal toggle */}
          {showQuarantinePrompt ? (
            <div className="p-4 rounded-lg border border-rose-500/30 bg-rose-500/10 space-y-3">
              <div className="text-xs font-semibold text-rose-200">
                Confirm Administrative Device Quarantine
              </div>
              <p className="text-xs text-slate-300">
                Quarantining this device will immediately sever all WireGuard peer tunnels and revoke access across all protected VPC resources.
              </p>
              <input
                type="text"
                placeholder="Reason (e.g. Lost device, suspect IOC detected)"
                value={quarantineReasonInput}
                onChange={e => setQuarantineReasonInput(e.target.value)}
                className="w-full text-xs bg-slate-900 border border-slate-700 rounded p-2 text-slate-200 focus:outline-none focus:border-rose-400"
              />
              <div className="flex items-center gap-2 justify-end">
                <button
                  onClick={() => setShowQuarantinePrompt(false)}
                  className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  onClick={handleQuarantine}
                  className="px-3 py-1.5 text-xs font-medium text-white bg-rose-600 hover:bg-rose-500 rounded"
                >
                  Confirm Quarantine
                </button>
              </div>
            </div>
          ) : null}
        </div>

        {/* Footer */}
        <div className="border-t border-slate-800 px-5 py-3 bg-slate-950/60 flex items-center justify-between text-xs">
          {device.trustLevel === 'quarantined' ? (
            <button
              onClick={() => unquarantineDevice(device.id)}
              className="inline-flex items-center gap-1.5 text-emerald-400 hover:text-emerald-300 font-medium"
            >
              <CheckCircle2 className="h-4 w-4" />
              <span>Lift Quarantine</span>
            </button>
          ) : (
            <button
              onClick={() => setShowQuarantinePrompt(true)}
              className="inline-flex items-center gap-1.5 text-rose-400 hover:text-rose-300 font-medium"
            >
              <Ban className="h-4 w-4" />
              <span>Quarantine Endpoint</span>
            </button>
          )}

          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
