import React, { useState } from 'react';
import { useZtna } from '../context/ZtnaContext';
import { X, Clock, Key, ShieldCheck, AlertCircle } from 'lucide-react';

export const JitAccessModal: React.FC = () => {
  const {
    isJitModalOpen,
    setIsJitModalOpen,
    applications,
    createJitRequest,
    selectedDeviceForDaemon
  } = useZtna();

  const [resourceId, setResourceId] = useState<string>(applications[0]?.id || '');
  const [durationMinutes, setDurationMinutes] = useState<number>(30);
  const [reason, setReason] = useState<string>('');
  const [submitted, setSubmitted] = useState<boolean>(false);

  if (!isJitModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) return;

    createJitRequest(resourceId, durationMinutes, reason.trim());
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setReason('');
      setIsJitModalOpen(false);
    }, 1200);
  };

  const selectedApp = applications.find(a => a.id === resourceId);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
      <div className="w-full max-w-lg rounded-lg border border-slate-800 bg-slate-900 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 px-5 py-3.5 bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="flex h-7 w-7 items-center justify-center rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <Key className="h-4 w-4" />
            </div>
            <div>
              <div className="text-sm font-semibold text-white">
                Request Ephemeral Just-in-Time Access
              </div>
              <div className="text-xs text-slate-400">
                Temporary elevated privilege with automatic session revocation
              </div>
            </div>
          </div>
          <button
            onClick={() => setIsJitModalOpen(false)}
            className="rounded p-1 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Content */}
        {submitted ? (
          <div className="p-8 text-center space-y-3">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              <ShieldCheck className="h-6 w-6" />
            </div>
            <h3 className="text-base font-semibold text-white">
              JIT Request Dispatched
            </h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              Your ephemeral access request has been submitted to SecOps reviewers and directory approvers.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-5 space-y-4">
            <div className="p-3 rounded border border-slate-800 bg-slate-950/40 text-xs text-slate-300">
              Requester:{' '}
              <span className="font-semibold text-white">
                {selectedDeviceForDaemon.userName} ({selectedDeviceForDaemon.userEmail})
              </span>
              <br />
              Role: <span className="text-slate-400">{selectedDeviceForDaemon.userRole}</span>
            </div>

            <div>
              <label className="text-xs font-medium text-slate-300 mb-1.5 block">
                Target Protected Resource
              </label>
              <select
                value={resourceId}
                onChange={e => setResourceId(e.target.value)}
                className="w-full text-xs bg-slate-800 border border-slate-700 rounded-md px-3 py-2 text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                {applications.map(app => (
                  <option key={app.id} value={app.id}>
                    {app.name} ({app.protocol}) · {app.posturePolicyProfile}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs font-medium text-slate-300 mb-1.5 flex items-center justify-between">
                <span>Access Window Duration</span>
                <span className="text-cyan-400 font-mono">{durationMinutes} minutes</span>
              </label>
              <div className="grid grid-cols-4 gap-2">
                {[15, 30, 60, 120].map(mins => (
                  <button
                    key={mins}
                    type="button"
                    onClick={() => setDurationMinutes(mins)}
                    className={`py-1.5 text-xs font-medium rounded border transition-colors ${
                      durationMinutes === mins
                        ? 'border-cyan-500 bg-cyan-500/20 text-cyan-200'
                        : 'border-slate-800 bg-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {mins}m
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-xs font-medium text-slate-300 mb-1.5 block">
                Justification & Ticket Reference
              </label>
              <textarea
                required
                rows={3}
                placeholder="e.g. Resolving incident #INC-893 postgres connection pool exhaustion in us-east-1"
                value={reason}
                onChange={e => setReason(e.target.value)}
                className="w-full text-xs bg-slate-800 border border-slate-700 rounded-md p-2.5 text-slate-200 focus:outline-none focus:border-cyan-500 placeholder:text-slate-500 resize-none"
              />
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setIsJitModalOpen(false)}
                className="px-3.5 py-1.5 text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!reason.trim()}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 disabled:pointer-events-none rounded-md transition-colors"
              >
                Submit Request
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
