import React, { useState } from 'react';
import { useZtna } from '../context/ZtnaContext';
import { AccessPolicy, EdrAgentType } from '../types/ztna';
import { X, Shield, Plus, Check } from 'lucide-react';

interface PolicyEditorModalProps {
  policy?: AccessPolicy | null;
  onClose: () => void;
}

export const PolicyEditorModal: React.FC<PolicyEditorModalProps> = ({ policy, onClose }) => {
  const { addPolicy, updatePolicy, applications, policies } = useZtna();

  const [name, setName] = useState(policy?.name || '');
  const [description, setDescription] = useState(policy?.description || '');
  const [action, setAction] = useState<AccessPolicy['action']>(policy?.action || 'ALLOW');
  const [allowedGroups, setAllowedGroups] = useState<string[]>(
    policy?.identityConditions.allowedUserGroups || ['Engineering']
  );
  const [requireDiskEncryption, setRequireDiskEncryption] = useState<boolean>(
    policy?.deviceConditions.requireDiskEncryption ?? true
  );
  const [requireEdr, setRequireEdr] = useState<boolean>(
    policy?.deviceConditions.requireEdr ?? true
  );
  const [allowedEdrs, setAllowedEdrs] = useState<EdrAgentType[]>(
    policy?.deviceConditions.allowedEdrAgents || ['crowdstrike', 'sentinelone', 'defender']
  );
  const [requireFirewall, setRequireFirewall] = useState<boolean>(
    policy?.deviceConditions.requireFirewall ?? true
  );
  const [maxScreenLock, setMaxScreenLock] = useState<number>(
    policy?.deviceConditions.maxScreenLockMin || 10
  );
  const [targetResourceIds, setTargetResourceIds] = useState<string[]>(
    policy?.targetResourceIds || []
  );

  const ALL_GROUPS = ['Engineering', 'Infrastructure', 'SecOps', 'Executive', 'Contractors', 'Finance'];
  const ALL_EDRS: { id: EdrAgentType; label: string }[] = [
    { id: 'crowdstrike', label: 'CrowdStrike Falcon' },
    { id: 'sentinelone', label: 'SentinelOne Singularity' },
    { id: 'defender', label: 'Microsoft Defender ATP' }
  ];

  const handleToggleGroup = (group: string) => {
    if (allowedGroups.includes(group)) {
      setAllowedGroups(allowedGroups.filter(g => g !== group));
    } else {
      setAllowedGroups([...allowedGroups, group]);
    }
  };

  const handleToggleEdr = (edr: EdrAgentType) => {
    if (allowedEdrs.includes(edr)) {
      setAllowedEdrs(allowedEdrs.filter(e => e !== edr));
    } else {
      setAllowedEdrs([...allowedEdrs, edr]);
    }
  };

  const handleToggleResource = (resId: string) => {
    if (targetResourceIds.includes(resId)) {
      setTargetResourceIds(targetResourceIds.filter(id => id !== resId));
    } else {
      setTargetResourceIds([...targetResourceIds, resId]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const payload = {
      priority: policy?.priority || policies.length + 1,
      name: name.trim(),
      description: description.trim(),
      enabled: policy?.enabled ?? true,
      identityConditions: {
        allowedUserGroups: allowedGroups
      },
      deviceConditions: {
        requireDiskEncryption,
        requireEdr,
        allowedEdrAgents: allowedEdrs,
        requireFirewall,
        maxScreenLockMin: maxScreenLock,
        disallowJailbreak: true,
        allowedCountries: ['US', 'DE', 'IE', 'GB', 'CA']
      },
      targetResourceIds,
      action,
      createdAt: policy?.createdAt || new Date().toISOString()
    };

    if (policy) {
      updatePolicy(policy.id, payload);
    } else {
      addPolicy(payload);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
      <div className="w-full max-w-2xl rounded-lg border border-slate-800 bg-slate-900 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 px-5 py-3.5 bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="flex h-7 w-7 items-center justify-center rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <Shield className="h-4 w-4" />
            </div>
            <div>
              <div className="text-sm font-semibold text-white">
                {policy ? 'Edit Access Policy' : 'Create Zero Trust Access Policy'}
              </div>
              <div className="text-xs text-slate-400">
                Define identity requirements and device posture gates
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded p-1 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Content Form */}
        <form onSubmit={handleSubmit} className="overflow-y-auto p-5 space-y-4">
          <div>
            <label className="text-xs font-medium text-slate-300 mb-1 block">
              Policy Name
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Tier-0 Production Database Strict Policy"
              value={name}
              onChange={e => setName(e.target.value)}
              className="w-full text-xs bg-slate-800 border border-slate-700 rounded p-2 text-slate-200 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div>
            <label className="text-xs font-medium text-slate-300 mb-1 block">
              Description & Scope
            </label>
            <input
              type="text"
              placeholder="Brief summary of what this policy enforces"
              value={description}
              onChange={e => setDescription(e.target.value)}
              className="w-full text-xs bg-slate-800 border border-slate-700 rounded p-2 text-slate-200 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Action Decision */}
          <div>
            <label className="text-xs font-medium text-slate-300 mb-1.5 block">
              Policy Action When Criteria Met
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'ALLOW', label: 'Allow Access', desc: 'Tunnel established' },
                { id: 'STEP_UP_MFA', label: 'Step-Up MFA', desc: 'Require FIDO2 touch' },
                { id: 'QUARANTINE_BLOCK', label: 'Quarantine & Block', desc: 'Sever connection' }
              ].map(act => (
                <button
                  key={act.id}
                  type="button"
                  onClick={() => setAction(act.id as any)}
                  className={`p-2.5 rounded text-left border transition-colors ${
                    action === act.id
                      ? 'border-cyan-500 bg-cyan-500/10 text-cyan-200'
                      : 'border-slate-800 bg-slate-800/60 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <div className="text-xs font-semibold">{act.label}</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">{act.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Allowed Groups */}
          <div>
            <label className="text-xs font-medium text-slate-300 mb-1.5 block">
              Allowed IdP Directory Groups
            </label>
            <div className="flex flex-wrap gap-1.5">
              {ALL_GROUPS.map(grp => {
                const selected = allowedGroups.includes(grp);
                return (
                  <button
                    key={grp}
                    type="button"
                    onClick={() => handleToggleGroup(grp)}
                    className={`px-2.5 py-1 rounded text-xs font-medium border transition-colors ${
                      selected
                        ? 'border-cyan-500/40 bg-cyan-500/20 text-cyan-300'
                        : 'border-slate-800 bg-slate-800/80 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {grp}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Device Posture Conditions */}
          <div className="p-3.5 rounded-lg border border-slate-800 bg-slate-950/40 space-y-3">
            <div className="text-xs font-semibold text-slate-200">
              Continuous Device Posture Gates
            </div>

            <div className="space-y-2">
              <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={requireDiskEncryption}
                  onChange={e => setRequireDiskEncryption(e.target.checked)}
                  className="rounded border-slate-700 bg-slate-800 text-cyan-500 focus:ring-0"
                />
                <span>Require Full Disk Encryption (FileVault / BitLocker / LUKS)</span>
              </label>

              <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={requireFirewall}
                  onChange={e => setRequireFirewall(e.target.checked)}
                  className="rounded border-slate-700 bg-slate-800 text-cyan-500 focus:ring-0"
                />
                <span>Require Host Application Firewall Active</span>
              </label>

              <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={requireEdr}
                  onChange={e => setRequireEdr(e.target.checked)}
                  className="rounded border-slate-700 bg-slate-800 text-cyan-500 focus:ring-0"
                />
                <span>Require Active Enterprise EDR Sensor</span>
              </label>

              {requireEdr && (
                <div className="pl-6 pt-1 flex flex-wrap gap-2">
                  {ALL_EDRS.map(edr => {
                    const sel = allowedEdrs.includes(edr.id);
                    return (
                      <button
                        key={edr.id}
                        type="button"
                        onClick={() => handleToggleEdr(edr.id)}
                        className={`text-xs px-2 py-0.5 rounded border transition-colors ${
                          sel
                            ? 'border-indigo-500/40 bg-indigo-500/20 text-indigo-300'
                            : 'border-slate-800 text-slate-400'
                        }`}
                      >
                        {edr.label}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Target Resources */}
          <div>
            <label className="text-xs font-medium text-slate-300 mb-1.5 block">
              Target Protected Resources (Leave blank to govern all catalog items)
            </label>
            <div className="grid grid-cols-2 gap-2 max-h-36 overflow-y-auto p-1 border border-slate-800 rounded bg-slate-950/20">
              {applications.map(app => {
                const sel = targetResourceIds.includes(app.id);
                return (
                  <button
                    key={app.id}
                    type="button"
                    onClick={() => handleToggleResource(app.id)}
                    className={`p-2 rounded text-left border text-xs transition-colors ${
                      sel
                        ? 'border-cyan-500 bg-cyan-500/10 text-cyan-200'
                        : 'border-slate-800/80 bg-slate-800/40 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <div className="font-semibold truncate">{app.name}</div>
                    <div className="text-[10px] text-slate-400">{app.protocol} · {app.allowedPorts[0]}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Footer controls */}
          <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded-md transition-colors"
            >
              {policy ? 'Save Changes' : 'Create Policy'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
