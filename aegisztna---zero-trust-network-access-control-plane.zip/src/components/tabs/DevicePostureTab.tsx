import React, { useState } from 'react';
import { useZtna } from '../../context/ZtnaContext';
import { DevicePosture, PostureTrustLevel } from '../../types/ztna';
import {
  ShieldCheck,
  ShieldAlert,
  Laptop,
  HardDrive,
  Flame,
  Cpu,
  Search,
  RefreshCw,
  Ban,
  Activity,
  CheckCircle2,
  XCircle,
  AlertTriangle
} from 'lucide-react';

interface DevicePostureTabProps {
  onOpenDeviceDetail: (device: DevicePosture) => void;
}

export const DevicePostureTab: React.FC<DevicePostureTabProps> = ({ onOpenDeviceDetail }) => {
  const { devices, quarantineDevice, unquarantineDevice, triggerDeviceScan } = useZtna();
  const [filterTrust, setFilterTrust] = useState<string>('all');
  const [search, setSearch] = useState('');

  const compliantCount = devices.filter(d => d.trustLevel === 'compliant').length;
  const warningCount = devices.filter(d => d.trustLevel === 'warning').length;
  const quarantinedCount = devices.filter(d => d.trustLevel === 'quarantined').length;

  const filteredDevices = devices.filter(d => {
    const matchesFilter = filterTrust === 'all' || d.trustLevel === filterTrust;
    const matchesSearch =
      d.deviceName.toLowerCase().includes(search.toLowerCase()) ||
      d.userName.toLowerCase().includes(search.toLowerCase()) ||
      d.userEmail.toLowerCase().includes(search.toLowerCase()) ||
      d.virtualIp.includes(search);
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Overview Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-lg border border-slate-800 bg-slate-900/60 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400">Total Enrolled Endpoints</div>
            <div className="text-2xl font-bold text-white font-mono tabular-nums mt-1">
              {devices.length}
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">WireGuard client daemons</div>
          </div>
          <div className="flex h-10 w-10 items-center justify-center rounded bg-slate-800 text-slate-300">
            <Laptop className="h-5 w-5" />
          </div>
        </div>

        <div className="p-4 rounded-lg border border-slate-800 bg-slate-900/60 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400">Fully Compliant</div>
            <div className="text-2xl font-bold text-emerald-400 font-mono tabular-nums mt-1">
              {compliantCount}
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">All posture gates satisfied</div>
          </div>
          <div className="flex h-10 w-10 items-center justify-center rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <ShieldCheck className="h-5 w-5" />
          </div>
        </div>

        <div className="p-4 rounded-lg border border-slate-800 bg-slate-900/60 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400">Posture Warnings</div>
            <div className="text-2xl font-bold text-amber-400 font-mono tabular-nums mt-1">
              {warningCount}
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">Minor compliance drift</div>
          </div>
          <div className="flex h-10 w-10 items-center justify-center rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <AlertTriangle className="h-5 w-5" />
          </div>
        </div>

        <div className="p-4 rounded-lg border border-slate-800 bg-slate-900/60 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400">Quarantined Endpoints</div>
            <div className="text-2xl font-bold text-rose-400 font-mono tabular-nums mt-1">
              {quarantinedCount}
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">Access severed immediately</div>
          </div>
          <div className="flex h-10 w-10 items-center justify-center rounded bg-rose-500/10 text-rose-400 border border-rose-500/20">
            <Ban className="h-5 w-5" />
          </div>
        </div>
      </div>

      {/* Posture Engine Standards Explainer */}
      <div className="p-4 rounded-lg border border-slate-800 bg-slate-900/40 text-xs text-slate-300 grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="flex items-start gap-2.5">
          <HardDrive className="h-4 w-4 text-indigo-400 shrink-0 mt-0.5" />
          <div>
            <div className="font-semibold text-slate-200">Disk Encryption</div>
            <div className="text-slate-400 text-[11px] mt-0.5">
              Requires FileVault, BitLocker, or LUKS with AES-XTS 256.
            </div>
          </div>
        </div>

        <div className="flex items-start gap-2.5">
          <Activity className="h-4 w-4 text-cyan-400 shrink-0 mt-0.5" />
          <div>
            <div className="font-semibold text-slate-200">Continuous EDR</div>
            <div className="text-slate-400 text-[11px] mt-0.5">
              CrowdStrike Falcon or SentinelOne sensor must be actively executing.
            </div>
          </div>
        </div>

        <div className="flex items-start gap-2.5">
          <Flame className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <div className="font-semibold text-slate-200">Host Firewall</div>
            <div className="text-slate-400 text-[11px] mt-0.5">
              OS-level packet filtering must be enabled to block rogue ingress.
            </div>
          </div>
        </div>

        <div className="flex items-start gap-2.5">
          <Cpu className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
          <div>
            <div className="font-semibold text-slate-200">Hardware Attestation</div>
            <div className="text-slate-400 text-[11px] mt-0.5">
              TPM 2.0 or Apple Secure Enclave binds cryptographic client certs.
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex items-center gap-1 p-1 bg-slate-900/80 border border-slate-800 rounded-lg">
          {[
            { id: 'all', label: 'All Endpoints' },
            { id: 'compliant', label: 'Compliant' },
            { id: 'warning', label: 'Warnings' },
            { id: 'quarantined', label: 'Quarantined' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setFilterTrust(tab.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                filterTrust === tab.id
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search endpoint, user, IP..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full text-xs bg-slate-900 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>
      </div>

      {/* Device Table */}
      <div className="rounded-lg border border-slate-800 bg-slate-900/40 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-slate-800 bg-slate-950/60 text-slate-400 font-medium">
              <tr>
                <th className="px-4 py-3">Endpoint & User</th>
                <th className="px-4 py-3">OS / Architecture</th>
                <th className="px-4 py-3">Virtual IP</th>
                <th className="px-4 py-3">Posture Breakdown</th>
                <th className="px-4 py-3">Trust Level</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filteredDevices.map(device => {
                return (
                  <tr
                    key={device.id}
                    className="hover:bg-slate-800/40 transition-colors"
                  >
                    {/* User & Endpoint */}
                    <td className="px-4 py-3.5">
                      <div
                        onClick={() => onOpenDeviceDetail(device)}
                        className="font-semibold text-slate-200 hover:text-cyan-300 cursor-pointer transition-colors"
                      >
                        {device.deviceName}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {device.userName} · {device.userDepartment}
                      </div>
                    </td>

                    {/* OS */}
                    <td className="px-4 py-3.5 text-slate-300">
                      <div>{device.osType}</div>
                      <div className="text-[11px] font-mono text-slate-500">{device.osVersion}</div>
                    </td>

                    {/* Virtual IP */}
                    <td className="px-4 py-3.5 font-mono text-cyan-300 tabular-nums">
                      {device.virtualIp}
                    </td>

                    {/* Posture Breakdown */}
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-2 text-[11px]">
                        <span
                          title={`Disk: ${device.diskEncryption}`}
                          className={device.diskEncryption === 'encrypted' ? 'text-emerald-400' : 'text-rose-400'}
                        >
                          Disk: {device.diskEncryption}
                        </span>
                        <span aria-hidden="true" className="text-slate-600">·</span>
                        <span
                          title={`EDR: ${device.edrAgent} (${device.edrStatus})`}
                          className={device.edrStatus === 'running' ? 'text-emerald-400' : 'text-rose-400'}
                        >
                          EDR: {device.edrStatus}
                        </span>
                        <span aria-hidden="true" className="text-slate-600">·</span>
                        <span
                          title={`Firewall: ${device.firewallActive ? 'Active' : 'Disabled'}`}
                          className={device.firewallActive ? 'text-emerald-400' : 'text-rose-400'}
                        >
                          FW: {device.firewallActive ? 'On' : 'Off'}
                        </span>
                      </div>
                    </td>

                    {/* Trust Level */}
                    <td className="px-4 py-3.5">
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium capitalize ${
                          device.trustLevel === 'compliant'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : device.trustLevel === 'warning'
                            ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                            : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                        }`}
                      >
                        {device.trustLevel}
                      </span>
                    </td>

                    {/* Actions */}
                    <td className="px-4 py-3.5 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => triggerDeviceScan(device.id)}
                          className="p-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800"
                          title="Trigger Posture Scan"
                        >
                          <RefreshCw className="h-3.5 w-3.5" />
                        </button>

                        <button
                          onClick={() => onOpenDeviceDetail(device)}
                          className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium"
                        >
                          Inspect
                        </button>

                        {device.trustLevel === 'quarantined' ? (
                          <button
                            onClick={() => unquarantineDevice(device.id)}
                            className="px-2.5 py-1 rounded bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 text-xs font-medium border border-emerald-500/30"
                          >
                            Restore
                          </button>
                        ) : (
                          <button
                            onClick={() =>
                              quarantineDevice(device.id, 'Administrative manual isolation')
                            }
                            className="px-2.5 py-1 rounded bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 text-xs font-medium border border-rose-500/30"
                          >
                            Quarantine
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
