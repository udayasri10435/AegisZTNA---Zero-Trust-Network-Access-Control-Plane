import React, { useState } from 'react';
import { useZtna } from '../../context/ZtnaContext';
import { AccessAuditLog } from '../../types/ztna';
import {
  Activity,
  CheckCircle2,
  XCircle,
  ShieldAlert,
  Search,
  Filter,
  Eye,
  Clock,
  Laptop,
  Server,
  X
} from 'lucide-react';

export const TrafficAuditTab: React.FC = () => {
  const { auditLogs } = useZtna();
  const [filterDecision, setFilterDecision] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLog, setSelectedLog] = useState<AccessAuditLog | null>(null);

  const filteredLogs = auditLogs.filter(log => {
    const matchesDecision = filterDecision === 'all' || log.decision === filterDecision;
    const matchesSearch =
      log.userEmail.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.resourceName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.clientVirtualIp.includes(searchQuery);
    return matchesDecision && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-lg border border-slate-800 bg-slate-900/60 backdrop-blur-sm">
        <div>
          <h2 className="text-base font-semibold text-white">
            Live Zero Trust Decision & Packet Inspector
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Every session request is continuously verified at the edge connector. If device posture
            drifts mid-connection or identity groups revoke, access is terminated immediately.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-400">
          <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>Real-time Edge Stream Active</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex items-center gap-1 p-1 bg-slate-900/80 border border-slate-800 rounded-lg">
          {[
            { id: 'all', label: 'All Decisions' },
            { id: 'ALLOW', label: 'Allowed' },
            { id: 'DENIED', label: 'Denied' },
            { id: 'MFA_CHALLENGE', label: 'MFA Challenges' },
            { id: 'QUARANTINE', label: 'Quarantined' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setFilterDecision(tab.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                filterDecision === tab.id
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
          <input
            type="text"
            placeholder="Filter user, app, or virtual IP..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full text-xs bg-slate-900 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="rounded-lg border border-slate-800 bg-slate-900/40 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-slate-800 bg-slate-950/60 text-slate-400 font-medium">
              <tr>
                <th className="px-4 py-3">Timestamp</th>
                <th className="px-4 py-3">Identity / Endpoint</th>
                <th className="px-4 py-3">Target Application</th>
                <th className="px-4 py-3">Evaluated Policy</th>
                <th className="px-4 py-3">Verdict</th>
                <th className="px-4 py-3">Edge POP</th>
                <th className="px-4 py-3 text-right">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filteredLogs.map(log => {
                const formattedTime = new Date(log.timestamp).toLocaleTimeString([], {
                  hour: '2-digit',
                  minute: '2-digit',
                  second: '2-digit'
                });

                return (
                  <tr
                    key={log.id}
                    onClick={() => setSelectedLog(log)}
                    className="hover:bg-slate-800/40 cursor-pointer transition-colors"
                  >
                    {/* Timestamp */}
                    <td className="px-4 py-3 text-slate-400 font-mono tabular-nums whitespace-nowrap">
                      {formattedTime}
                    </td>

                    {/* Identity */}
                    <td className="px-4 py-3">
                      <div className="font-semibold text-slate-200">{log.userName}</div>
                      <div className="text-[11px] font-mono text-cyan-400/80 tabular-nums">
                        {log.clientVirtualIp}
                      </div>
                    </td>

                    {/* Target Application */}
                    <td className="px-4 py-3">
                      <div className="text-slate-200 font-medium">{log.resourceName}</div>
                      <div className="text-[11px] font-mono text-slate-400">{log.protocol}</div>
                    </td>

                    {/* Evaluated Policy */}
                    <td className="px-4 py-3 text-slate-300">
                      <span className="truncate max-w-[200px] block" title={log.evaluatedPolicyName}>
                        {log.evaluatedPolicyName}
                      </span>
                    </td>

                    {/* Verdict */}
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span
                        className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[11px] font-mono font-medium ${
                          log.decision === 'ALLOW'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : log.decision === 'MFA_CHALLENGE'
                            ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                            : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                        }`}
                      >
                        {log.decision === 'ALLOW' && <CheckCircle2 className="h-3.5 w-3.5" />}
                        {log.decision === 'MFA_CHALLENGE' && <ShieldAlert className="h-3.5 w-3.5" />}
                        {log.decision === 'DENIED' && <XCircle className="h-3.5 w-3.5" />}
                        {log.decision === 'QUARANTINE' && <XCircle className="h-3.5 w-3.5" />}
                        <span>{log.decision}</span>
                      </span>
                    </td>

                    {/* Edge POP */}
                    <td className="px-4 py-3 font-mono text-slate-400 tabular-nums">
                      {log.edgePop} · {log.latencyMs}ms
                    </td>

                    {/* Action */}
                    <td className="px-4 py-3 text-right">
                      <button className="text-slate-400 hover:text-white p-1">
                        <Eye className="h-3.5 w-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Selected Log Detail Drawer Modal */}
      {selectedLog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="w-full max-w-xl rounded-lg border border-slate-800 bg-slate-900 shadow-2xl overflow-hidden flex flex-col">
            <div className="flex items-center justify-between border-b border-slate-800 px-5 py-3.5 bg-slate-950/60">
              <div className="flex items-center gap-2">
                <Activity className="h-4 w-4 text-cyan-400" />
                <span className="text-sm font-semibold text-white">Access Decision Inspection</span>
              </div>
              <button
                onClick={() => setSelectedLog(null)}
                className="rounded p-1 text-slate-400 hover:bg-slate-800 hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              <div
                className={`p-3 rounded border font-medium ${
                  selectedLog.decision === 'ALLOW'
                    ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300'
                    : selectedLog.decision === 'MFA_CHALLENGE'
                    ? 'border-amber-500/30 bg-amber-500/10 text-amber-300'
                    : 'border-rose-500/30 bg-rose-500/10 text-rose-300'
                }`}
              >
                <div className="font-semibold text-sm">Verdict: {selectedLog.decision}</div>
                <div className="mt-1 space-y-0.5 text-xs text-slate-300">
                  {selectedLog.reasons.map((r, i) => (
                    <div key={i}>• {r}</div>
                  ))}
                </div>
              </div>

              <div className="space-y-2 border border-slate-800 rounded-lg p-3.5 bg-slate-950/30">
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Timestamp:</span>
                  <span className="font-mono text-slate-200">{selectedLog.timestamp}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">User Identity:</span>
                  <span className="text-slate-200">
                    {selectedLog.userName} ({selectedLog.userEmail})
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Device Name:</span>
                  <span className="text-slate-200">{selectedLog.deviceName}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Virtual WireGuard IP:</span>
                  <span className="font-mono text-cyan-300">{selectedLog.clientVirtualIp}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Target Protected App:</span>
                  <span className="text-slate-200">{selectedLog.resourceName}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Target Protocol:</span>
                  <span className="font-mono text-slate-200">{selectedLog.protocol}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Governing Policy:</span>
                  <span className="text-slate-200">{selectedLog.evaluatedPolicyName}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Edge Connector:</span>
                  <span className="font-mono text-emerald-400">
                    {selectedLog.edgePop} ({selectedLog.latencyMs}ms RTT)
                  </span>
                </div>
              </div>
            </div>

            <div className="border-t border-slate-800 px-5 py-3 bg-slate-950/60 flex justify-end">
              <button
                onClick={() => setSelectedLog(null)}
                className="px-3.5 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium"
              >
                Close Trace
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
