import React, { useState } from 'react';
import { useZtna } from '../../context/ZtnaContext';
import { ApplicationResource, AppCategory } from '../../types/ztna';
import {
  Search,
  Plus,
  Server,
  Database,
  Terminal,
  Layers,
  Monitor,
  ExternalLink,
  ShieldCheck,
  ShieldAlert,
  Radio,
  Clock,
  Key
} from 'lucide-react';

interface ApplicationsTabProps {
  onOpenAppDetail: (app: ApplicationResource) => void;
  onOpenAddApp: () => void;
}

export const ApplicationsTab: React.FC<ApplicationsTabProps> = ({
  onOpenAppDetail,
  onOpenAddApp
}) => {
  const { applications, testAndLogAccess, setIsJitModalOpen, clientDaemon } = useZtna();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [launchingAppId, setLaunchingAppId] = useState<string | null>(null);
  const [launchResult, setLaunchResult] = useState<{ id: string; decision: string } | null>(null);

  const categories: { id: string; label: string }[] = [
    { id: 'all', label: 'All Resources' },
    { id: 'web_internal', label: 'Web Portals' },
    { id: 'database', label: 'Databases' },
    { id: 'bastion_ssh', label: 'SSH Bastions' },
    { id: 'kubernetes', label: 'Kubernetes' },
    { id: 'rdp', label: 'RDP Systems' }
  ];

  const filteredApps = applications.filter(app => {
    const matchesSearch =
      app.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.publicFqdn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.allowedPorts.some(p => p.toString().includes(searchQuery));
    const matchesCat = selectedCategory === 'all' || app.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  const getCategoryIcon = (category: AppCategory) => {
    switch (category) {
      case 'database':
        return <Database className="h-4 w-4 text-cyan-400" />;
      case 'bastion_ssh':
        return <Terminal className="h-4 w-4 text-emerald-400" />;
      case 'kubernetes':
        return <Layers className="h-4 w-4 text-indigo-400" />;
      case 'rdp':
        return <Monitor className="h-4 w-4 text-amber-400" />;
      default:
        return <Server className="h-4 w-4 text-blue-400" />;
    }
  };

  const handleLaunchTunnel = async (appId: string) => {
    setLaunchingAppId(appId);
    setLaunchResult(null);
    try {
      const res = await testAndLogAccess(appId);
      setLaunchResult({ id: appId, decision: res.decision });
      setTimeout(() => setLaunchResult(null), 3500);
    } finally {
      setLaunchingAppId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner / Explainer */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-lg border border-slate-800 bg-slate-900/60 backdrop-blur-sm">
        <div>
          <h2 className="text-base font-semibold text-white">
            Per-Application Micro-Segmented Access
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Unlike legacy VPNs that expose the entire corporate subnet, Aegis creates discrete,
            on-demand WireGuard and mTLS reverse tunnels directly to individual application ports.
            Lateral movement is cryptographically prohibited.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsJitModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-amber-300 border border-amber-500/30 bg-amber-500/10 hover:bg-amber-500/20 rounded transition-colors"
          >
            <Key className="h-3.5 w-3.5" />
            <span>Request JIT Access</span>
          </button>

          <button
            onClick={onOpenAddApp}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded transition-colors"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>Add Protected Resource</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Category Tabs */}
        <div className="flex items-center gap-1 p-1 bg-slate-900/80 border border-slate-800 rounded-lg overflow-x-auto">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                selectedCategory === cat.id
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search FQDN, port, name..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full text-xs bg-slate-900 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>
      </div>

      {/* Application Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredApps.map(app => {
          const isLaunching = launchingAppId === app.id;
          const result = launchResult?.id === app.id ? launchResult : null;

          return (
            <div
              key={app.id}
              className="flex flex-col justify-between rounded-lg border border-slate-800 bg-slate-900/40 hover:bg-slate-900/70 hover:border-slate-700/80 transition-all p-4 relative overflow-hidden"
            >
              <div>
                {/* Header row */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div className="flex h-8 w-8 items-center justify-center rounded bg-slate-800/90 border border-slate-700/60">
                      {getCategoryIcon(app.category)}
                    </div>
                    <div>
                      <h3
                        onClick={() => onOpenAppDetail(app)}
                        className="text-xs font-semibold text-white hover:text-cyan-300 cursor-pointer transition-colors"
                      >
                        {app.name}
                      </h3>
                      <div className="text-[11px] font-mono text-cyan-400/90 truncate max-w-[190px]">
                        {app.publicFqdn}
                      </div>
                    </div>
                  </div>

                  <span className="text-[11px] font-mono text-slate-400 tabular-nums">
                    {app.allowedPorts.map(p => `:${p}`).join(' ')}
                  </span>
                </div>

                <p className="text-xs text-slate-400 mt-2.5 line-clamp-2 leading-relaxed">
                  {app.description}
                </p>

                {/* Metadata row */}
                <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-3 pt-3 border-t border-slate-800/80">
                  <span className="capitalize">{app.posturePolicyProfile.replace('_', ' ')}</span>
                  <span aria-hidden="true">·</span>
                  <span>{app.protocol}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">{app.avgLatencyMs} ms</span>
                  <span aria-hidden="true">·</span>
                  <span>{app.activeSessionsCount} active</span>
                </div>
              </div>

              {/* Bottom Action Strip */}
              <div className="mt-4 pt-3 flex items-center justify-between gap-2">
                <button
                  onClick={() => onOpenAppDetail(app)}
                  className="text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors"
                >
                  Configure Route
                </button>

                <button
                  onClick={() => handleLaunchTunnel(app.id)}
                  disabled={isLaunching}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                    result?.decision === 'ALLOW'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : result?.decision === 'DENIED' || result?.decision === 'QUARANTINE'
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                      : result?.decision === 'MFA_CHALLENGE'
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : 'bg-cyan-600 hover:bg-cyan-500 text-white'
                  }`}
                >
                  {isLaunching ? (
                    <span>Verifying...</span>
                  ) : result ? (
                    <span>{result.decision}</span>
                  ) : (
                    <>
                      <span>Launch Tunnel</span>
                      <ExternalLink className="h-3 w-3" />
                    </>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {filteredApps.length === 0 && (
        <div className="p-12 text-center border border-slate-800 rounded-lg bg-slate-900/20">
          <Server className="h-8 w-8 text-slate-500 mx-auto mb-2" />
          <div className="text-sm font-semibold text-slate-300">No applications matched</div>
          <div className="text-xs text-slate-400 mt-1">
            Try adjusting your search query or category filter.
          </div>
        </div>
      )}
    </div>
  );
};
