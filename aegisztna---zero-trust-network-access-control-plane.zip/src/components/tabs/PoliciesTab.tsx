import React from 'react';
import { useZtna } from '../../context/ZtnaContext';
import { AccessPolicy } from '../../types/ztna';
import {
  Shield,
  Plus,
  ArrowUp,
  ArrowDown,
  Play,
  CheckCircle2,
  AlertTriangle,
  Lock,
  Layers,
  Edit2,
  Trash2,
  ToggleLeft,
  ToggleRight
} from 'lucide-react';

interface PoliciesTabProps {
  onOpenCreatePolicy: () => void;
  onEditPolicy: (policy: AccessPolicy) => void;
}

export const PoliciesTab: React.FC<PoliciesTabProps> = ({
  onOpenCreatePolicy,
  onEditPolicy
}) => {
  const {
    policies,
    togglePolicy,
    deletePolicy,
    reorderPolicies,
    setIsPolicySandboxOpen,
    applications
  } = useZtna();

  const sortedPolicies = [...policies].sort((a, b) => a.priority - b.priority);

  const getTargetResourceNames = (targetIds: string[]) => {
    if (targetIds.length === 0) return 'All Resources';
    return targetIds
      .map(id => applications.find(a => a.id === id)?.name || id)
      .join(', ');
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-lg border border-slate-800 bg-slate-900/60 backdrop-blur-sm">
        <div>
          <h2 className="text-base font-semibold text-white">
            Zero Trust Access Policy Engine
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Policies are evaluated sequentially from highest priority (Rank #1) to lowest. Access
            is dynamically evaluated upon every connection based on IdP directory groups, OS build,
            hardware TPM enclave, active EDR sensor, and geofencing.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setIsPolicySandboxOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 border border-slate-700 bg-slate-800 hover:bg-slate-700 rounded transition-colors"
          >
            <Play className="h-3.5 w-3.5 text-cyan-400" />
            <span>Test Policy Simulator</span>
          </button>

          <button
            onClick={onOpenCreatePolicy}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded transition-colors"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>New Access Policy</span>
          </button>
        </div>
      </div>

      {/* Policies List */}
      <div className="space-y-3">
        {sortedPolicies.map((policy, index) => {
          const isFirst = index === 0;
          const isLast = index === sortedPolicies.length - 1;

          return (
            <div
              key={policy.id}
              className={`rounded-lg border transition-all p-4 ${
                policy.enabled
                  ? 'border-slate-800 bg-slate-900/40 hover:border-slate-700'
                  : 'border-slate-800/50 bg-slate-950/40 opacity-60'
              }`}
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                {/* Left: Priority & Name */}
                <div className="flex items-start gap-3">
                  {/* Priority rank badge */}
                  <div className="flex flex-col items-center justify-center">
                    <span className="font-mono text-xs font-bold text-cyan-400 bg-slate-800 px-2 py-0.5 rounded border border-slate-700 tabular-nums">
                      #{policy.priority}
                    </span>
                    <div className="flex items-center gap-0.5 mt-1.5">
                      <button
                        disabled={isFirst}
                        onClick={() => reorderPolicies(index, index - 1)}
                        className="p-1 rounded text-slate-400 hover:bg-slate-800 hover:text-white disabled:opacity-20"
                        title="Move Up in Priority"
                      >
                        <ArrowUp className="h-3 w-3" />
                      </button>
                      <button
                        disabled={isLast}
                        onClick={() => reorderPolicies(index, index + 1)}
                        className="p-1 rounded text-slate-400 hover:bg-slate-800 hover:text-white disabled:opacity-20"
                        title="Move Down in Priority"
                      >
                        <ArrowDown className="h-3 w-3" />
                      </button>
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-semibold text-white">{policy.name}</h3>
                      <span
                        className={`text-[10px] font-mono font-medium px-2 py-0.5 rounded ${
                          policy.action === 'ALLOW'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : policy.action === 'STEP_UP_MFA'
                            ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                            : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                        }`}
                      >
                        ACTION: {policy.action}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-1 max-w-2xl">{policy.description}</p>

                    {/* Conditions preview tags */}
                    <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-400 mt-2.5">
                      <span>IdP: {policy.identityConditions.allowedUserGroups.join(', ')}</span>
                      <span aria-hidden="true">·</span>
                      {policy.deviceConditions.requireDiskEncryption && (
                        <>
                          <span>Encrypted Disk</span>
                          <span aria-hidden="true">·</span>
                        </>
                      )}
                      {policy.deviceConditions.requireFirewall && (
                        <>
                          <span>Firewall On</span>
                          <span aria-hidden="true">·</span>
                        </>
                      )}
                      {policy.deviceConditions.requireEdr && (
                        <>
                          <span>EDR Sensor ({policy.deviceConditions.allowedEdrAgents.join('/')})</span>
                          <span aria-hidden="true">·</span>
                        </>
                      )}
                      <span>Targets: {getTargetResourceNames(policy.targetResourceIds)}</span>
                    </div>
                  </div>
                </div>

                {/* Right: Actions */}
                <div className="flex items-center gap-2 self-end lg:self-center">
                  <button
                    onClick={() => togglePolicy(policy.id)}
                    className="inline-flex items-center gap-1 text-xs text-slate-400 hover:text-slate-200 px-2 py-1 rounded"
                    title={policy.enabled ? 'Disable Policy' : 'Enable Policy'}
                  >
                    {policy.enabled ? (
                      <ToggleRight className="h-5 w-5 text-cyan-400" />
                    ) : (
                      <ToggleLeft className="h-5 w-5 text-slate-600" />
                    )}
                  </button>

                  <button
                    onClick={() => onEditPolicy(policy)}
                    className="p-1.5 rounded text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
                    title="Edit Policy"
                  >
                    <Edit2 className="h-3.5 w-3.5" />
                  </button>

                  <button
                    onClick={() => deletePolicy(policy.id)}
                    className="p-1.5 rounded text-slate-400 hover:bg-rose-500/10 hover:text-rose-400 transition-colors"
                    title="Delete Policy"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}

        {/* Fallback rule footer */}
        <div className="p-3.5 rounded-lg border border-dashed border-slate-800 bg-slate-950/20 text-xs text-slate-500 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Lock className="h-4 w-4 text-slate-500" />
            <span>Implicit Zero Trust Fallback: Default Deny (Traffic not matched by any active rule is dropped)</span>
          </div>
          <span className="font-mono text-[10px] text-slate-600">RFC 3514</span>
        </div>
      </div>
    </div>
  );
};
