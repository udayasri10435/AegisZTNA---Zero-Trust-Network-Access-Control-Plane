import React, { useState } from 'react';
import { useZtna } from '../../context/ZtnaContext';
import {
  Globe,
  Server,
  Cloud,
  CheckCircle2,
  Copy,
  Terminal,
  Activity,
  Layers,
  ArrowRight
} from 'lucide-react';

export const GatewaysTab: React.FC = () => {
  const { gateways } = useZtna();
  const [copiedToken, setCopiedToken] = useState(false);

  const totalTunnels = gateways.reduce((acc, g) => acc + g.tunnelsActive, 0);
  const totalThroughput = gateways.reduce((acc, g) => acc + g.throughputMbps, 0);

  const copyInstallCommand = () => {
    navigator.clipboard.writeText(
      'curl -fsSL https://mesh.aegis-ztna.net/install.sh | sudo bash -s -- --token aegis_ctk_99812_prod'
    );
    setCopiedToken(true);
    setTimeout(() => setCopiedToken(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Mesh Overview Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-4 rounded-lg border border-slate-800 bg-slate-900/60 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400">Active Edge Connectors</div>
            <div className="text-2xl font-bold text-white font-mono tabular-nums mt-1">
              {gateways.length} Nodes
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">Distributed Anycast POPs</div>
          </div>
          <div className="flex h-10 w-10 items-center justify-center rounded bg-slate-800 text-cyan-400">
            <Globe className="h-5 w-5" />
          </div>
        </div>

        <div className="p-4 rounded-lg border border-slate-800 bg-slate-900/60 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400">Active WireGuard Tunnels</div>
            <div className="text-2xl font-bold text-emerald-400 font-mono tabular-nums mt-1">
              {totalTunnels}
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">Ephemeral peer-to-gateway flows</div>
          </div>
          <div className="flex h-10 w-10 items-center justify-center rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <Activity className="h-5 w-5" />
          </div>
        </div>

        <div className="p-4 rounded-lg border border-slate-800 bg-slate-900/60 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400">Aggregate Bandwidth</div>
            <div className="text-2xl font-bold text-cyan-400 font-mono tabular-nums mt-1">
              {(totalThroughput / 1000).toFixed(2)} Gbps
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">Direct line-rate throughput</div>
          </div>
          <div className="flex h-10 w-10 items-center justify-center rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <Layers className="h-5 w-5" />
          </div>
        </div>
      </div>

      {/* Gateway Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {gateways.map(gw => (
          <div
            key={gw.id}
            className="rounded-lg border border-slate-800 bg-slate-900/40 p-4 space-y-3"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="flex h-8 w-8 items-center justify-center rounded bg-slate-800 text-cyan-400">
                  <Cloud className="h-4 w-4" />
                </div>
                <div>
                  <h3 className="text-xs font-semibold text-white">{gw.name}</h3>
                  <div className="text-[11px] text-slate-400">{gw.region}</div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="font-mono text-xs font-semibold text-cyan-400 bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                  {gw.popCode}
                </span>
                <span className="flex items-center gap-1 text-[11px] font-medium text-emerald-400">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                  {gw.status.toUpperCase()}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs pt-1">
              <div className="p-2.5 rounded border border-slate-800/80 bg-slate-950/40">
                <span className="text-slate-400 block text-[11px]">WireGuard Endpoint</span>
                <span className="font-mono text-slate-200 mt-0.5 block truncate">
                  {gw.wireguardEndpoint}
                </span>
              </div>

              <div className="p-2.5 rounded border border-slate-800/80 bg-slate-950/40">
                <span className="text-slate-400 block text-[11px]">Public Egress IP</span>
                <span className="font-mono text-cyan-300 mt-0.5 block tabular-nums">
                  {gw.publicIp}
                </span>
              </div>

              <div className="p-2.5 rounded border border-slate-800/80 bg-slate-950/40">
                <span className="text-slate-400 block text-[11px]">Active Tunnels</span>
                <span className="font-mono text-emerald-400 font-semibold mt-0.5 block tabular-nums">
                  {gw.tunnelsActive} sessions
                </span>
              </div>

              <div className="p-2.5 rounded border border-slate-800/80 bg-slate-950/40">
                <span className="text-slate-400 block text-[11px]">Throughput</span>
                <span className="font-mono text-slate-200 mt-0.5 block tabular-nums">
                  {gw.throughputMbps.toFixed(1)} Mbps
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Deploy Lightweight App Connector */}
      <div className="p-5 rounded-lg border border-slate-800 bg-slate-900/40 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xs font-semibold text-white flex items-center gap-2">
              <Terminal className="h-4 w-4 text-cyan-400" />
              Deploy Zero-Inbound Edge Connector (Docker / Linux Daemon)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Connectors establish outbound-only tunnels to the nearest Aegis POP. No public IP or
              open inbound firewall ports required in your private cloud or on-prem datacenter.
            </p>
          </div>
        </div>

        <div className="flex items-center justify-between bg-slate-950 border border-slate-800 rounded-lg p-3">
          <code className="text-xs font-mono text-slate-300 truncate mr-3">
            curl -fsSL https://mesh.aegis-ztna.net/install.sh | sudo bash -s -- --token aegis_ctk_99812_prod
          </code>
          <button
            onClick={copyInstallCommand}
            className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 transition-colors flex items-center gap-1.5 shrink-0"
          >
            {copiedToken ? (
              <>
                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                <span className="text-emerald-400">Copied!</span>
              </>
            ) : (
              <>
                <Copy className="h-3.5 w-3.5" />
                <span>Copy</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
