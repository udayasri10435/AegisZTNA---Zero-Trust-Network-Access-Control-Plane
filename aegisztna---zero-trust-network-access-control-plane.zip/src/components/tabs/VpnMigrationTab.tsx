import React, { useState } from 'react';
import { useZtna } from '../../context/ZtnaContext';
import {
  ShieldAlert,
  ShieldCheck,
  ArrowRight,
  Network,
  Zap,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Sparkles,
  Server
} from 'lucide-react';

export const VpnMigrationTab: React.FC = () => {
  const { addApplication, addPolicy, applications } = useZtna();

  const [inputCidr, setInputCidr] = useState('10.240.0.0/16');
  const [scanning, setScanning] = useState(false);
  const [discoveredSubnet, setDiscoveredSubnet] = useState<boolean>(false);
  const [migratedSuccess, setMigratedSuccess] = useState<boolean>(false);

  const DISCOVERED_LEGACY_HOSTS = [
    {
      legacyIp: '10.240.12.8:5432',
      serviceName: 'Core FinTech Ledger DB',
      protocol: 'TCP' as const,
      suggestedZtnaName: 'FinTech Ledger PostgreSQL',
      suggestedFqdn: 'ledger.fintech.aegis-mesh.internal',
      category: 'database' as const,
      port: 5432,
      requiredGroup: 'Engineering'
    },
    {
      legacyIp: '10.240.18.22:443',
      serviceName: 'Corporate JIRA & Confluence',
      protocol: 'HTTPS' as const,
      suggestedZtnaName: 'Atlassian Internal Suite',
      suggestedFqdn: 'jira.corp.aegis-mesh.internal',
      category: 'web_internal' as const,
      port: 443,
      requiredGroup: 'Engineering'
    },
    {
      legacyIp: '10.240.4.99:22',
      serviceName: 'AWS Bastion Host Prod',
      protocol: 'SSH' as const,
      suggestedZtnaName: 'Secure Cloud SSH Jumpbox',
      suggestedFqdn: 'bastion-prod.aegis-mesh.internal',
      category: 'bastion_ssh' as const,
      port: 22,
      requiredGroup: 'Infrastructure'
    }
  ];

  const handleScanSubnet = () => {
    setScanning(true);
    setMigratedSuccess(false);
    setTimeout(() => {
      setScanning(false);
      setDiscoveredSubnet(true);
    }, 900);
  };

  const handleExecuteMigration = () => {
    // Add discovered items as real ZTNA resources
    DISCOVERED_LEGACY_HOSTS.forEach(host => {
      // Check if already added
      const exists = applications.some(a => a.publicFqdn === host.suggestedFqdn);
      if (!exists) {
        addApplication({
          name: host.suggestedZtnaName,
          slug: host.suggestedFqdn.replace(/\./g, '-'),
          description: `Migrated from legacy VPN subnet ${inputCidr} (${host.legacyIp})`,
          category: host.category,
          internalUri: `${host.protocol.toLowerCase()}://${host.legacyIp}`,
          publicFqdn: host.suggestedFqdn,
          gatewayId: 'gw-iad-01',
          allowedPorts: [host.port],
          protocol: host.protocol,
          posturePolicyProfile: 'corp_standard',
          mfaRequired: false,
          activeSessionsCount: 4,
          healthStatus: 'healthy',
          avgLatencyMs: 14,
          tags: ['migrated-from-vpn', 'micro-segmented']
        });
      }
    });

    // Add a migration policy
    addPolicy({
      priority: 6,
      name: `Migrated VPN Subnet Policy (${inputCidr})`,
      description: 'Enforces device posture on migrated legacy subnet applications',
      enabled: true,
      identityConditions: {
        allowedUserGroups: ['Engineering', 'Infrastructure', 'SecOps']
      },
      deviceConditions: {
        requireDiskEncryption: true,
        requireEdr: true,
        allowedEdrAgents: ['crowdstrike', 'sentinelone', 'defender'],
        requireFirewall: true,
        maxScreenLockMin: 15,
        disallowJailbreak: true,
        allowedCountries: ['US', 'DE', 'IE']
      },
      targetResourceIds: [],
      action: 'ALLOW',
      createdAt: new Date().toISOString()
    });

    setMigratedSuccess(true);
  };

  const COMPARISON_ROWS = [
    {
      dimension: 'Network Exposure',
      legacyVpn: 'Broad Layer-3 Subnet (e.g. 10.0.0.0/16). User receives route to the entire corporate subnet.',
      aegisZtna: 'Layer-7 & Port-specific micro-segmentation. User ONLY reaches the authorized target port.'
    },
    {
      dimension: 'Lateral Movement',
      legacyVpn: 'Severe Risk: Compromised laptop can probe, scan, and infect neighboring servers across the subnet.',
      aegisZtna: 'Zero Lateral Movement: Tunnels terminate at the app level. No host scanning or port sweeps possible.'
    },
    {
      dimension: 'Device Posture',
      legacyVpn: 'None or static login check. User can turn off firewall or get infected post-connect without severance.',
      aegisZtna: 'Continuous Evaluation: WireGuard session terminates within 60s if EDR stops or disk unencrypts.'
    },
    {
      dimension: 'Inbound Open Ports',
      legacyVpn: 'Concentrator firewall must expose open public UDP/TCP listening ports (target for DDoS & CVEs).',
      aegisZtna: 'Zero Open Inbound Ports. Edge connectors initiate outbound-only mTLS/WireGuard reverse tunnels.'
    },
    {
      dimension: 'Traffic Hairpinning',
      legacyVpn: 'All remote traffic backhauls through single HQ data center bottleneck before reaching SaaS/Cloud.',
      aegisZtna: 'Direct Anycast Edge Mesh. Optimal WireGuard routing to the nearest regional cloud POP.'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-5 rounded-lg border border-slate-800 bg-slate-900/60 backdrop-blur-sm">
        <h2 className="text-base font-semibold text-white">
          Why Modern Enterprises Replace VPNs with ZTNA
        </h2>
        <p className="text-xs text-slate-400 mt-1 max-w-3xl leading-relaxed">
          Legacy corporate VPNs were architected for a vanished world of centralized on-prem offices.
          ZTNA replaces static network perimeters with identity verification and endpoint device posture,
          delivering the security posture of Tailscale, Cloudflare Access, and Zscaler Private Access.
        </p>
      </div>

      {/* Comparison Matrix Table */}
      <div className="rounded-lg border border-slate-800 bg-slate-900/40 overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between">
          <span className="text-xs font-semibold text-white">
            Architecture Blueprint: Legacy Concentrator VPN vs. Aegis ZTNA
          </span>
          <span className="text-xs text-slate-400">Zero Trust Network Access Standard</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-slate-800 bg-slate-950/40 text-slate-400 font-medium">
              <tr>
                <th className="px-5 py-3 w-1/4">Security Dimension</th>
                <th className="px-5 py-3 w-3/8 text-rose-300">Legacy Corporate VPN</th>
                <th className="px-5 py-3 w-3/8 text-cyan-300">Aegis ZTNA Platform</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {COMPARISON_ROWS.map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-800/20 transition-colors">
                  <td className="px-5 py-3.5 font-semibold text-slate-200">
                    {row.dimension}
                  </td>
                  <td className="px-5 py-3.5 text-slate-400 leading-relaxed">
                    <div className="flex items-start gap-2">
                      <XCircle className="h-4 w-4 text-rose-400 shrink-0 mt-0.5" />
                      <span>{row.legacyVpn}</span>
                    </div>
                  </td>
                  <td className="px-5 py-3.5 text-slate-300 leading-relaxed">
                    <div className="flex items-start gap-2">
                      <CheckCircle2 className="h-4 w-4 text-cyan-400 shrink-0 mt-0.5" />
                      <span>{row.aegisZtna}</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Subnet-to-Per-App Migration Wizard */}
      <div className="rounded-lg border border-slate-800 bg-slate-900/40 p-5 space-y-4">
        <div>
          <h3 className="text-xs font-semibold text-white flex items-center gap-2">
            <Network className="h-4 w-4 text-cyan-400" />
            VPN Subnet-to-Per-App Migration Engine
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Import existing corporate VPN CIDR blocks. Aegis maps discovered internal services and
            converts them into isolated, identity-governed per-app ZTNA routes.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-3">
          <div className="w-full sm:w-80">
            <input
              type="text"
              value={inputCidr}
              onChange={e => setInputCidr(e.target.value)}
              placeholder="e.g. 10.240.0.0/16"
              className="w-full text-xs font-mono bg-slate-950 border border-slate-700 rounded-md p-2.5 text-slate-200 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <button
            onClick={handleScanSubnet}
            disabled={scanning}
            className="w-full sm:w-auto px-4 py-2 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-md transition-colors flex items-center justify-center gap-2 shrink-0"
          >
            {scanning ? (
              <span>Probing Subnet Services...</span>
            ) : (
              <>
                <Zap className="h-3.5 w-3.5 text-cyan-400" />
                <span>Scan Legacy Subnet</span>
              </>
            )}
          </button>
        </div>

        {/* Discovered services preview */}
        {discoveredSubnet && (
          <div className="border border-slate-800 rounded-lg p-4 bg-slate-950/50 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-200">
                Discovered Internal Services ({DISCOVERED_LEGACY_HOSTS.length} hosts found in {inputCidr})
              </span>
              <span className="text-xs text-emerald-400 flex items-center gap-1 font-mono">
                <CheckCircle2 className="h-3 w-3" /> Ready for Zero Trust Decoupling
              </span>
            </div>

            <div className="space-y-2">
              {DISCOVERED_LEGACY_HOSTS.map((host, i) => (
                <div
                  key={i}
                  className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-2.5 rounded border border-slate-800 bg-slate-900/60 text-xs"
                >
                  <div className="flex items-center gap-2.5">
                    <Server className="h-4 w-4 text-cyan-400 shrink-0" />
                    <div>
                      <div className="font-semibold text-slate-200">{host.serviceName}</div>
                      <div className="text-[11px] font-mono text-slate-400">
                        Legacy IP: <span className="text-rose-300">{host.legacyIp}</span> → New FQDN:{' '}
                        <span className="text-cyan-300">{host.suggestedFqdn}</span>
                      </div>
                    </div>
                  </div>

                  <span className="font-mono text-[10px] bg-slate-800 px-2 py-0.5 rounded text-slate-300 self-start sm:self-center">
                    {host.protocol}:{host.port}
                  </span>
                </div>
              ))}
            </div>

            <div className="pt-2 flex items-center justify-between">
              <p className="text-[11px] text-slate-400">
                Executing will register these 3 protected resources and generate corresponding device posture policies.
              </p>

              <button
                onClick={handleExecuteMigration}
                disabled={migratedSuccess}
                className={`px-4 py-2 text-xs font-semibold rounded-md transition-colors flex items-center gap-2 ${
                  migratedSuccess
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 cursor-default'
                    : 'bg-cyan-600 hover:bg-cyan-500 text-white'
                }`}
              >
                {migratedSuccess ? (
                  <>
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    <span>Migrated into Live Catalog!</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="h-3.5 w-3.5" />
                    <span>Apply Zero Trust Per-App Routing</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
