import React, { useState } from 'react';
import { useZtna } from '../context/ZtnaContext';
import { AppCategory, AppProtocol } from '../types/ztna';
import { X, Server, Plus } from 'lucide-react';

interface AddResourceModalProps {
  onClose: () => void;
}

export const AddResourceModal: React.FC<AddResourceModalProps> = ({ onClose }) => {
  const { addApplication, gateways } = useZtna();

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<AppCategory>('web_internal');
  const [internalUri, setInternalUri] = useState('');
  const [publicFqdn, setPublicFqdn] = useState('');
  const [gatewayId, setGatewayId] = useState(gateways[0]?.id || 'gw-iad-01');
  const [protocol, setProtocol] = useState<AppProtocol>('HTTPS');
  const [port, setPort] = useState<number>(443);
  const [posturePolicyProfile, setPosturePolicyProfile] = useState<'strict_prod' | 'corp_standard' | 'contractor_limited'>('corp_standard');
  const [mfaRequired, setMfaRequired] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !publicFqdn.trim()) return;

    addApplication({
      name: name.trim(),
      slug: publicFqdn.replace(/\./g, '-'),
      description: description.trim() || 'Internal protected resource under Zero Trust proxy',
      category,
      internalUri: internalUri.trim() || `https://${publicFqdn}`,
      publicFqdn: publicFqdn.trim(),
      gatewayId,
      allowedPorts: [Number(port) || 443],
      protocol,
      posturePolicyProfile,
      mfaRequired,
      activeSessionsCount: 0,
      healthStatus: 'healthy',
      avgLatencyMs: 14,
      tags: ['ztna-protected', category]
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
      <div className="w-full max-w-xl rounded-lg border border-slate-800 bg-slate-900 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 px-5 py-3.5 bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="flex h-7 w-7 items-center justify-center rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <Server className="h-4 w-4" />
            </div>
            <div>
              <div className="text-sm font-semibold text-white">
                Add Protected Application Resource
              </div>
              <div className="text-xs text-slate-400">
                Bind an internal service to an isolated Zero Trust WireGuard route
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded p-1 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Content Form */}
        <form onSubmit={handleSubmit} className="overflow-y-auto p-5 space-y-4 text-xs">
          <div>
            <label className="font-medium text-slate-300 mb-1 block">Resource Name</label>
            <input
              type="text"
              required
              placeholder="e.g. Analytics ClickHouse Cluster"
              value={name}
              onChange={e => setName(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-slate-200 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-medium text-slate-300 mb-1 block">Category</label>
              <select
                value={category}
                onChange={e => setCategory(e.target.value as any)}
                className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                <option value="web_internal">Web Internal Portal</option>
                <option value="database">Database (SQL / NoSQL)</option>
                <option value="bastion_ssh">SSH Bastion</option>
                <option value="kubernetes">Kubernetes Control Plane</option>
                <option value="rdp">Windows RDP Host</option>
              </select>
            </div>

            <div>
              <label className="font-medium text-slate-300 mb-1 block">Protocol</label>
              <select
                value={protocol}
                onChange={e => setProtocol(e.target.value as any)}
                className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                <option value="HTTPS">HTTPS</option>
                <option value="TCP">TCP</option>
                <option value="SSH">SSH</option>
                <option value="K8S">K8S API</option>
                <option value="RDP">RDP</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-medium text-slate-300 mb-1 block">Public ZTNA FQDN</label>
              <input
                type="text"
                required
                placeholder="analytics.aegis-mesh.internal"
                value={publicFqdn}
                onChange={e => setPublicFqdn(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-slate-200 font-mono focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="font-medium text-slate-300 mb-1 block">Allowed Port</label>
              <input
                type="number"
                required
                value={port}
                onChange={e => setPort(Number(e.target.value))}
                className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-slate-200 font-mono focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          <div>
            <label className="font-medium text-slate-300 mb-1 block">
              Internal VPC Destination URI
            </label>
            <input
              type="text"
              placeholder="e.g. https://clickhouse.internal.vpc:8123"
              value={internalUri}
              onChange={e => setInternalUri(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-slate-200 font-mono focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-medium text-slate-300 mb-1 block">Egress Edge Gateway</label>
              <select
                value={gatewayId}
                onChange={e => setGatewayId(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                {gateways.map(g => (
                  <option key={g.id} value={g.id}>
                    {g.name} ({g.popCode})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="font-medium text-slate-300 mb-1 block">Posture Profile</label>
              <select
                value={posturePolicyProfile}
                onChange={e => setPosturePolicyProfile(e.target.value as any)}
                className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                <option value="strict_prod">Strict Production (Tier-0)</option>
                <option value="corp_standard">Corporate Standard</option>
                <option value="contractor_limited">Contractor Limited</option>
              </select>
            </div>
          </div>

          <div className="pt-2">
            <label className="flex items-center gap-2 cursor-pointer text-slate-300">
              <input
                type="checkbox"
                checked={mfaRequired}
                onChange={e => setMfaRequired(e.target.checked)}
                className="rounded border-slate-700 bg-slate-800 text-cyan-500 focus:ring-0"
              />
              <span>Require FIDO2 / WebAuthn Step-up Challenge on Every Session</span>
            </label>
          </div>

          <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded-md transition-colors"
            >
              Save & Publish Route
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
