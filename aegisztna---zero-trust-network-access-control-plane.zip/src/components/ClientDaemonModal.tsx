import React, { useState } from 'react';
import { useZtna } from '../context/ZtnaContext';
import {
  X,
  Laptop,
  Power,
  Shield,
  ShieldCheck,
  ShieldAlert,
  HardDrive,
  Flame,
  Activity,
  ArrowUpRight,
  ArrowDownLeft,
  RotateCw,
  ExternalLink,
  CheckCircle2,
  XCircle,
  HelpCircle
} from 'lucide-react';

export const ClientDaemonModal: React.FC = () => {
  const {
    clientDaemon,
    selectedDeviceForDaemon,
    setSelectedDeviceForDaemon,
    devices,
    applications,
    toggleDaemonConnection,
    setClientOverride,
    resetClientOverrides,
    testAndLogAccess,
    isDaemonModalOpen,
    setIsDaemonModalOpen
  } = useZtna();

  const [testingAppId, setTestingAppId] = useState<string>('app-pg-prod');
  const [testResult, setTestResult] = useState<any | null>(null);
  const [isTesting, setIsTesting] = useState(false);

  if (!isDaemonModalOpen) return null;

  const currentDisk =
    clientDaemon.overrideDiskEncryption !== undefined
      ? clientDaemon.overrideDiskEncryption
      : selectedDeviceForDaemon.diskEncryption;

  const currentEdr =
    clientDaemon.overrideEdrStatus !== undefined
      ? clientDaemon.overrideEdrStatus
      : selectedDeviceForDaemon.edrStatus;

  const currentFirewall =
    clientDaemon.overrideFirewall !== undefined
      ? clientDaemon.overrideFirewall
      : selectedDeviceForDaemon.firewallActive;

  const handleRunTest = async () => {
    setIsTesting(true);
    setTestResult(null);
    try {
      const res = await testAndLogAccess(testingAppId);
      setTestResult(res);
    } finally {
      setIsTesting(false);
    }
  };

  const formatBytes = (bytes: number) => {
    if (bytes >= 1048576) return `${(bytes / 1048576).toFixed(1)} MB`;
    return `${(bytes / 1024).toFixed(0)} KB`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="w-full max-w-2xl rounded-lg border border-slate-800 bg-slate-900 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 px-5 py-3.5 bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="flex h-7 w-7 items-center justify-center rounded bg-slate-800 text-cyan-400">
              <Laptop className="h-4 w-4" />
            </div>
            <div>
              <div className="text-sm font-semibold text-white">
                Aegis Client Daemon Simulator
              </div>
              <div className="text-xs text-slate-400">
                Local WireGuard Tunnel & Continuous Posture Agent
              </div>
            </div>
          </div>
          <button
            onClick={() => setIsDaemonModalOpen(false)}
            className="rounded p-1 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Content */}
        <div className="overflow-y-auto p-5 space-y-5">
          {/* Identity & Device Selector */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-lg border border-slate-800 bg-slate-950/40">
            <div>
              <div className="text-xs font-medium text-slate-400">Simulate Endpoint As:</div>
              <div className="text-sm font-semibold text-slate-200 mt-0.5">
                {selectedDeviceForDaemon.userName} ({selectedDeviceForDaemon.userDepartment})
              </div>
              <div className="text-xs text-slate-400">
                {selectedDeviceForDaemon.deviceName} · {selectedDeviceForDaemon.osType}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <select
                value={selectedDeviceForDaemon.id}
                onChange={e => {
                  const dev = devices.find(d => d.id === e.target.value);
                  if (dev) {
                    setSelectedDeviceForDaemon(dev);
                    resetClientOverrides();
                    setTestResult(null);
                  }
                }}
                className="text-xs bg-slate-800 border border-slate-700 rounded px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                {devices.map(d => (
                  <option key={d.id} value={d.id}>
                    {d.userName} ({d.osType})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Connection Status Box */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-4 rounded-lg border border-slate-800 bg-slate-950/50 flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-400">WireGuard State</span>
                <button
                  onClick={toggleDaemonConnection}
                  className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                    clientDaemon.connected
                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/20'
                      : 'bg-rose-500/10 text-rose-400 border border-rose-500/30 hover:bg-rose-500/20'
                  }`}
                >
                  <Power className="h-3 w-3" />
                  <span>{clientDaemon.connected ? 'Connected' : 'Disconnected'}</span>
                </button>
              </div>

              <div className="mt-3 space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Virtual CGNAT IP:</span>
                  <span className="font-mono text-cyan-300 tabular-nums">
                    {clientDaemon.assignedVirtualIp}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Target Gateway:</span>
                  <span className="text-slate-300">{clientDaemon.connectedPop}</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Tunnel Latency:</span>
                  <span className="font-mono text-emerald-400 tabular-nums">
                    {clientDaemon.connected ? `${clientDaemon.tunnelLatencyMs} ms` : 'Offline'}
                  </span>
                </div>
              </div>
            </div>

            <div className="p-4 rounded-lg border border-slate-800 bg-slate-950/50 flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-400">Telemetry Data</span>
                <span className="text-xs text-slate-400 flex items-center gap-1">
                  <Activity className="h-3 w-3 text-cyan-400" /> Continuous Sync
                </span>
              </div>

              <div className="mt-3 space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400 flex items-center gap-1">
                    <ArrowDownLeft className="h-3 w-3 text-emerald-400" /> Received:
                  </span>
                  <span className="font-mono text-slate-200 tabular-nums">
                    {formatBytes(clientDaemon.bytesReceived)}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400 flex items-center gap-1">
                    <ArrowUpRight className="h-3 w-3 text-cyan-400" /> Transmitted:
                  </span>
                  <span className="font-mono text-slate-200 tabular-nums">
                    {formatBytes(clientDaemon.bytesTransmitted)}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Cipher Protocol:</span>
                  <span className="font-mono text-slate-300">ChaCha20-Poly1305</span>
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Posture Switchboard */}
          <div className="border border-slate-800 rounded-lg p-4 bg-slate-950/30">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h4 className="text-xs font-semibold text-slate-200">
                  Interactive Posture Switchboard
                </h4>
                <p className="text-xs text-slate-400">
                  Toggle device conditions to test how ZTNA dynamically revokes or grants access.
                </p>
              </div>
              <button
                onClick={resetClientOverrides}
                className="inline-flex items-center gap-1 text-xs text-slate-400 hover:text-slate-200"
              >
                <RotateCw className="h-3 w-3" />
                <span>Reset Defaults</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {/* Firewall Control */}
              <div className="p-2.5 rounded border border-slate-800 bg-slate-900/60">
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="text-slate-300 flex items-center gap-1">
                    <Flame className="h-3.5 w-3.5 text-amber-400" /> Firewall
                  </span>
                  <span
                    className={`font-medium ${
                      currentFirewall ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {currentFirewall ? 'Active' : 'Disabled'}
                  </span>
                </div>
                <button
                  onClick={() => setClientOverride('overrideFirewall', !currentFirewall)}
                  className="w-full text-center text-xs py-1 rounded border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
                >
                  {currentFirewall ? 'Turn Off (Test Fail)' : 'Turn On (Pass)'}
                </button>
              </div>

              {/* EDR Agent Control */}
              <div className="p-2.5 rounded border border-slate-800 bg-slate-900/60">
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="text-slate-300 flex items-center gap-1">
                    <Shield className="h-3.5 w-3.5 text-cyan-400" /> EDR Sensor
                  </span>
                  <span
                    className={`font-medium ${
                      currentEdr === 'running' ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {currentEdr === 'running' ? 'Running' : 'Stopped'}
                  </span>
                </div>
                <button
                  onClick={() =>
                    setClientOverride(
                      'overrideEdrStatus',
                      currentEdr === 'running' ? 'stopped' : 'running'
                    )
                  }
                  className="w-full text-center text-xs py-1 rounded border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
                >
                  {currentEdr === 'running' ? 'Kill Sensor' : 'Start Sensor'}
                </button>
              </div>

              {/* Disk Encryption Control */}
              <div className="p-2.5 rounded border border-slate-800 bg-slate-900/60">
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="text-slate-300 flex items-center gap-1">
                    <HardDrive className="h-3.5 w-3.5 text-indigo-400" /> Encryption
                  </span>
                  <span
                    className={`font-medium ${
                      currentDisk === 'encrypted' ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {currentDisk === 'encrypted' ? 'Encrypted' : 'Disabled'}
                  </span>
                </div>
                <button
                  onClick={() =>
                    setClientOverride(
                      'overrideDiskEncryption',
                      currentDisk === 'encrypted' ? 'disabled' : 'encrypted'
                    )
                  }
                  className="w-full text-center text-xs py-1 rounded border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
                >
                  {currentDisk === 'encrypted' ? 'Decrypt (Test Fail)' : 'Encrypt (Pass)'}
                </button>
              </div>
            </div>
          </div>

          {/* Test Access Sandbox */}
          <div className="border border-slate-800 rounded-lg p-4 bg-slate-950/40">
            <h4 className="text-xs font-semibold text-slate-200 mb-2">
              Instant Access Verification
            </h4>
            <div className="flex flex-col sm:flex-row gap-2">
              <select
                value={testingAppId}
                onChange={e => {
                  setTestingAppId(e.target.value);
                  setTestResult(null);
                }}
                className="flex-1 text-xs bg-slate-800 border border-slate-700 rounded px-3 py-2 text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                {applications.map(app => (
                  <option key={app.id} value={app.id}>
                    {app.name} ({app.protocol}) - {app.posturePolicyProfile}
                  </option>
                ))}
              </select>

              <button
                onClick={handleRunTest}
                disabled={isTesting}
                className="px-4 py-2 text-xs font-medium text-white bg-cyan-600 rounded hover:bg-cyan-500 transition-colors flex items-center justify-center gap-1.5 whitespace-nowrap"
              >
                {isTesting ? (
                  <span>Evaluating...</span>
                ) : (
                  <>
                    <span>Verify Connection</span>
                    <ExternalLink className="h-3 w-3" />
                  </>
                )}
              </button>
            </div>

            {/* Test Output Banner */}
            {testResult && (
              <div
                className={`mt-3 p-3 rounded border text-xs ${
                  testResult.decision === 'ALLOW'
                    ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-200'
                    : testResult.decision === 'MFA_CHALLENGE'
                    ? 'border-amber-500/30 bg-amber-500/10 text-amber-200'
                    : 'border-rose-500/30 bg-rose-500/10 text-rose-200'
                }`}
              >
                <div className="flex items-center gap-2 font-semibold">
                  {testResult.decision === 'ALLOW' && (
                    <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                  )}
                  {testResult.decision === 'MFA_CHALLENGE' && (
                    <ShieldAlert className="h-4 w-4 text-amber-400" />
                  )}
                  {testResult.decision === 'DENIED' && (
                    <XCircle className="h-4 w-4 text-rose-400" />
                  )}
                  {testResult.decision === 'QUARANTINE' && (
                    <XCircle className="h-4 w-4 text-rose-400" />
                  )}
                  <span>Decision: {testResult.decision}</span>
                  {testResult.matchedPolicy && (
                    <span className="text-slate-400 font-normal">
                      · Matched: {testResult.matchedPolicy.name}
                    </span>
                  )}
                </div>

                <div className="mt-1.5 space-y-1">
                  {testResult.reasons.map((r: string, idx: number) => (
                    <div key={idx} className="text-slate-300">
                      • {r}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-slate-800 px-5 py-3 bg-slate-950/60 flex items-center justify-between text-xs text-slate-400">
          <span>Continuous Posture Loop: Active (60s cycle)</span>
          <button
            onClick={() => setIsDaemonModalOpen(false)}
            className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium"
          >
            Close Daemon
          </button>
        </div>
      </div>
    </div>
  );
};
