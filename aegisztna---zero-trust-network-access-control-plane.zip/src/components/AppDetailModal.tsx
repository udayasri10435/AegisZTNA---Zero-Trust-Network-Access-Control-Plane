import React, { useState } from 'react';
import { useZtna } from '../context/ZtnaContext';
import { ApplicationResource } from '../types/ztna';
import {
  X,
  Server,
  Shield,
  ExternalLink,
  Lock,
  Globe,
  Radio,
  CheckCircle2,
  Trash2,
  Play
} from 'lucide-react';

interface AppDetailModalProps {
  app: ApplicationResource;
  onClose: () => void;
}

export const AppDetailModal: React.FC<AppDetailModalProps> = ({ app, onClose }) => {
  const { gateways, testAndLogAccess, deleteApplication, updateApplication, setIsJitModalOpen } = useZtna();
  const [testing, setTesting] = useState(false);
  const [result, setResult] = useState<any | null>(null);

  const matchedGateway = gateways.find(g => g.id === app.gatewayId);

  const handleTest = async () => {
    setTesting(true);
    setResult(null);
    try {
      const res = await testAndLogAccess(app.id);
      setResult(res);
    } finally {
      setTesting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
      <div className="w-full max-w-2xl rounded-lg border border-slate-800 bg-slate-900 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 px-5 py-3.5 bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <Server className="h-4 w-4" />
            </div>
            <div>
              <div className="text-sm font-semibold text-white">{app.name}</div>
              <div className="text-xs text-slate-400 font-mono">{app.publicFqdn}</div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded p-1 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Content */}
        <div className="overflow-y-auto p-5 space-y-4">
          <div className="text-xs text-slate-300">{app.description}</div>

          {/* Grid stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <div className="p-3 rounded border border-slate-800 bg-slate-950/40">
              <div className="text-xs text-slate-400">Protocol</div>
              <div className="text-sm font-mono font-semibold text-cyan-300 mt-1">
                {app.protocol}
              </div>
            </div>

            <div className="p-3 rounded border border-slate-800 bg-slate-950/40">
              <div className="text-xs text-slate-400">Allowed Ports</div>
              <div className="text-sm font-mono font-semibold text-slate-200 mt-1">
                {app.allowedPorts.join(', ')}
              </div>
            </div>

            <div className="p-3 rounded border border-slate-800 bg-slate-950/40">
              <div className="text-xs text-slate-400">Posture Policy</div>
              <div className="text-sm font-semibold text-slate-200 mt-1 capitalize">
                {app.posturePolicyProfile.replace('_', ' ')}
              </div>
            </div>

            <div className="p-3 rounded border border-slate-800 bg-slate-950/40">
              <div className="text-xs text-slate-400">Avg Latency</div>
              <div className="text-sm font-mono font-semibold text-emerald-400 mt-1 tabular-nums">
                {app.avgLatencyMs} ms
              </div>
            </div>
          </div>

          {/* Routing & Topology Blueprint */}
          <div className="rounded-lg border border-slate-800 p-4 bg-slate-950/40 space-y-2.5">
            <h4 className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
              <Globe className="h-3.5 w-3.5 text-cyan-400" />
              Encapsulated Reverse Tunnel Architecture
            </h4>
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-800/80">
                <span className="text-slate-400">Public ZTNA FQDN:</span>
                <span className="font-mono text-cyan-300">{app.publicFqdn}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/80">
                <span className="text-slate-400">Target Internal VPC URI:</span>
                <span className="font-mono text-slate-300">{app.internalUri}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/80">
                <span className="text-slate-400">Bound Edge Gateway:</span>
                <span className="text-slate-300">
                  {matchedGateway ? `${matchedGateway.name} (${matchedGateway.popCode})` : 'Mesh Anycast'}
                </span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-400">MFA Step-Up Enforcement:</span>
                <span className={app.mfaRequired ? 'text-amber-400 font-medium' : 'text-slate-400'}>
                  {app.mfaRequired ? 'Required (FIDO2 / TOTP)' : 'Bypassed if Posture Compliant'}
                </span>
              </div>
            </div>
          </div>

          {/* Test access block */}
          <div className="p-4 rounded-lg border border-slate-800 bg-slate-950/40">
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-xs font-semibold text-slate-200">
                Live Tunnel Verification
              </h4>
              <button
                onClick={handleTest}
                disabled={testing}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-cyan-600 hover:bg-cyan-500 rounded transition-colors disabled:opacity-50"
              >
                <Play className="h-3 w-3 fill-current" />
                <span>{testing ? 'Probing...' : 'Initiate mTLS Handshake'}</span>
              </button>
            </div>

            {result && (
              <div
                className={`mt-2 p-3 rounded border text-xs ${
                  result.decision === 'ALLOW'
                    ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-200'
                    : result.decision === 'MFA_CHALLENGE'
                    ? 'border-amber-500/30 bg-amber-500/10 text-amber-200'
                    : 'border-rose-500/30 bg-rose-500/10 text-rose-200'
                }`}
              >
                <div className="font-semibold">Verdict: {result.decision}</div>
                <div className="mt-1 space-y-0.5">
                  {result.reasons.map((r: string, idx: number) => (
                    <div key={idx}>• {r}</div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-slate-800 px-5 py-3 bg-slate-950/60 flex items-center justify-between text-xs">
          <button
            onClick={() => {
              deleteApplication(app.id);
              onClose();
            }}
            className="text-rose-400 hover:text-rose-300 flex items-center gap-1"
          >
            <Trash2 className="h-3.5 w-3.5" />
            <span>Remove Resource</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                setIsJitModalOpen(true);
              }}
              className="px-3 py-1.5 rounded border border-amber-500/30 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 font-medium transition-colors"
            >
              Request JIT Access
            </button>
            <button
              onClick={onClose}
              className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium transition-colors"
            >
              Done
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
