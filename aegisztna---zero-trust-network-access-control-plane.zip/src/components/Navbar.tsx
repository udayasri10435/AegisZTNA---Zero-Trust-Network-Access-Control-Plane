import React from 'react';
import { useZtna } from '../context/ZtnaContext';
import { Shield, Laptop, Play, ShieldAlert } from 'lucide-react';

export type NavTab = 'apps' | 'policies' | 'posture' | 'traffic' | 'gateways' | 'migration';

interface NavbarProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab }) => {
  const {
    clientDaemon,
    selectedDeviceForDaemon,
    setIsDaemonModalOpen,
    setIsPolicySandboxOpen,
    jitRequests
  } = useZtna();

  const pendingJitCount = jitRequests.filter(r => r.status === 'pending').length;

  const navItems: { id: NavTab; label: string }[] = [
    { id: 'apps', label: 'Applications' },
    { id: 'policies', label: 'Access Policies' },
    { id: 'posture', label: 'Device Posture' },
    { id: 'traffic', label: 'Traffic & Audit' },
    { id: 'gateways', label: 'Edge Gateways' },
    { id: 'migration', label: 'VPN Migration' }
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800 bg-slate-950/90 backdrop-blur-md">
      <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Zone 1: Single text wordmark */}
        <button
          onClick={() => setActiveTab('apps')}
          className="flex items-center gap-2.5 text-left group transition-opacity"
        >
          <div className="flex h-7 w-7 items-center justify-center rounded-md bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 group-hover:border-cyan-400/50 transition-colors">
            <Shield className="h-4 w-4" />
          </div>
          <span className="text-base font-semibold tracking-tight text-white">
            Aegis ZTNA
          </span>
        </button>

        {/* Zone 2: 4-6 text navigation links */}
        <nav className="hidden md:flex items-center gap-6">
          {navItems.map(item => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`relative py-1 text-sm font-medium transition-colors whitespace-nowrap ${
                  isActive
                    ? 'text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {item.label}
                {isActive && (
                  <span className="absolute inset-x-0 -bottom-[17px] h-0.5 bg-cyan-400" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setIsPolicySandboxOpen(true)}
            className="hidden sm:inline-flex items-center gap-1.5 rounded-md border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-800 hover:border-slate-600 transition-colors"
          >
            <Play className="h-3.5 w-3.5 text-cyan-400" />
            <span>Policy Sandbox</span>
          </button>

          <button
            onClick={() => setIsDaemonModalOpen(true)}
            className={`inline-flex items-center gap-2 rounded-md border px-3 py-1.5 text-xs font-medium transition-colors ${
              clientDaemon.connected
                ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300 hover:bg-emerald-500/20'
                : 'border-slate-700 bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Laptop className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Client Agent</span>
            <span
              className={`h-2 w-2 rounded-full ${
                clientDaemon.connected ? 'bg-emerald-400' : 'bg-slate-500'
              }`}
            />
          </button>

          {pendingJitCount > 0 && (
            <div className="hidden lg:flex items-center text-xs text-amber-400 bg-amber-500/10 border border-amber-500/30 px-2.5 py-1 rounded-md">
              <ShieldAlert className="h-3.5 w-3.5 mr-1" />
              <span>{pendingJitCount} JIT Request</span>
            </div>
          )}
        </div>
      </div>

      {/* Mobile nav bar row for small screens */}
      <div className="flex md:hidden border-t border-slate-800/80 px-4 py-2 overflow-x-auto gap-4 text-xs font-medium scrollbar-none">
        {navItems.map(item => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`whitespace-nowrap py-1 ${
              activeTab === item.id ? 'text-cyan-400 font-semibold' : 'text-slate-400'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>
    </header>
  );
};
