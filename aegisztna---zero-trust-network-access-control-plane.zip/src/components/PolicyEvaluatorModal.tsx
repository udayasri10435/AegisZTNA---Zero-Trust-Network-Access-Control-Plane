import React, { useState } from 'react';
import { useZtna, EvaluationResult } from '../context/ZtnaContext';
import {
  X,
  Play,
  CheckCircle2,
  XCircle,
  Shield,
  Laptop,
  Layers,
  ArrowRight,
  ShieldCheck,
  ShieldAlert
} from 'lucide-react';

export const PolicyEvaluatorModal: React.FC = () => {
  const {
    isPolicySandboxOpen,
    setIsPolicySandboxOpen,
    devices,
    applications,
    policies,
    evaluateAccess
  } = useZtna();

  const [selectedDeviceId, setSelectedDeviceId] = useState<string>(devices[0]?.id || '');
  const [selectedAppId, setSelectedAppId] = useState<string>(applications[0]?.id || '');
  const [evaluation, setEvaluation] = useState<EvaluationResult | null>(null);

  if (!isPolicySandboxOpen) return null;

  const currentDevice = devices.find(d => d.id === selectedDeviceId) || devices[0];
  const currentApp = applications.find(a => a.id === selectedAppId) || applications[0];

  const handleEvaluate = () => {
    if (!currentDevice || !currentApp) return;
    const result = evaluateAccess(currentDevice.userEmail, currentDevice.id, currentApp.id);
    setEvaluation(result);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
      <div className="w-full max-w-3xl rounded-lg border border-slate-800 bg-slate-900 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 px-5 py-3.5 bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="flex h-7 w-7 items-center justify-center rounded bg-slate-800 text-cyan-400">
              <Play className="h-4 w-4" />
            </div>
            <div>
              <div className="text-sm font-semibold text-white">
                Zero Trust Policy Simulation Sandbox
              </div>
              <div className="text-xs text-slate-400">
                Dry-run policy evaluation against live identity & device posture
              </div>
            </div>
          </div>
          <button
            onClick={() => setIsPolicySandboxOpen(false)}
            className="rounded p-1 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Content */}
        <div className="overflow-y-auto p-5 space-y-5">
          {/* Controls */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 rounded-lg border border-slate-800 bg-slate-950/40">
            <div>
              <label className="text-xs font-medium text-slate-400 mb-1.5 flex items-center gap-1.5">
                <Laptop className="h-3.5 w-3.5 text-cyan-400" />
                Select Identity & Endpoint
              </label>
              <select
                value={selectedDeviceId}
                onChange={e => {
                  setSelectedDeviceId(e.target.value);
                  setEvaluation(null);
                }}
                className="w-full text-xs bg-slate-800 border border-slate-700 rounded-md px-3 py-2 text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                {devices.map(dev => (
                  <option key={dev.id} value={dev.id}>
                    {dev.userName} — {dev.deviceName} ({dev.osType})
                  </option>
                ))}
              </select>

              {currentDevice && (
                <div className="mt-2 text-xs text-slate-400 space-y-0.5">
                  <div>
                    Dept: <span className="text-slate-300">{currentDevice.userDepartment}</span> ·
                    EDR: <span className="text-slate-300">{currentDevice.edrAgent} ({currentDevice.edrStatus})</span>
                  </div>
                  <div>
                    Disk:{' '}
                    <span className="text-slate-300">{currentDevice.diskEncryption}</span> ·
                    Firewall:{' '}
                    <span className="text-slate-300">
                      {currentDevice.firewallActive ? 'Active' : 'Disabled'}
                    </span>
                  </div>
                </div>
              )}
            </div>

            <div>
              <label className="text-xs font-medium text-slate-400 mb-1.5 flex items-center gap-1.5">
                <Layers className="h-3.5 w-3.5 text-cyan-400" />
                Target Protected Application
              </label>
              <select
                value={selectedAppId}
                onChange={e => {
                  setSelectedAppId(e.target.value);
                  setEvaluation(null);
                }}
                className="w-full text-xs bg-slate-800 border border-slate-700 rounded-md px-3 py-2 text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                {applications.map(app => (
                  <option key={app.id} value={app.id}>
                    {app.name} ({app.protocol}) · {app.posturePolicyProfile}
                  </option>
                ))}
              </select>

              {currentApp && (
                <div className="mt-2 text-xs text-slate-400 space-y-0.5">
                  <div>
                    Internal URI: <span className="font-mono text-slate-300">{currentApp.internalUri}</span>
                  </div>
                  <div>
                    Profile: <span className="text-slate-300">{currentApp.posturePolicyProfile}</span> ·
                    MFA Required: <span className="text-slate-300">{currentApp.mfaRequired ? 'Yes' : 'No'}</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="flex justify-center">
            <button
              onClick={handleEvaluate}
              className="px-5 py-2 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded-md transition-colors flex items-center gap-2 shadow-sm"
            >
              <Play className="h-3.5 w-3.5 fill-current" />
              <span>Simulate Zero Trust Access Decision</span>
            </button>
          </div>

          {/* Results section */}
          {evaluation && (
            <div className="space-y-4">
              {/* Decision Box */}
              <div
                className={`p-4 rounded-lg border ${
                  evaluation.decision === 'ALLOW'
                    ? 'border-emerald-500/30 bg-emerald-500/10'
                    : evaluation.decision === 'MFA_CHALLENGE'
                    ? 'border-amber-500/30 bg-amber-500/10'
                    : 'border-rose-500/30 bg-rose-500/10'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {evaluation.decision === 'ALLOW' && (
                      <CheckCircle2 className="h-5 w-5 text-emerald-400" />
                    )}
                    {evaluation.decision === 'MFA_CHALLENGE' && (
                      <ShieldAlert className="h-5 w-5 text-amber-400" />
                    )}
                    {evaluation.decision === 'DENIED' && (
                      <XCircle className="h-5 w-5 text-rose-400" />
                    )}
                    {evaluation.decision === 'QUARANTINE' && (
                      <XCircle className="h-5 w-5 text-rose-400" />
                    )}
                    <div>
                      <div className="text-sm font-semibold text-white">
                        Evaluation Verdict: {evaluation.decision}
                      </div>
                      <div className="text-xs text-slate-300">
                        {evaluation.matchedPolicy
                          ? `Governed by Policy: ${evaluation.matchedPolicy.name} (Priority #${evaluation.matchedPolicy.priority})`
                          : 'No matching permit policy found — Default Deny enforced'}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-3 space-y-1 text-xs">
                  {evaluation.reasons.map((r, i) => (
                    <div key={i} className="text-slate-300">
                      • {r}
                    </div>
                  ))}
                </div>
              </div>

              {/* Evaluation Step-by-Step Trace */}
              <div className="border border-slate-800 rounded-lg p-4 bg-slate-950/30">
                <h4 className="text-xs font-semibold text-slate-200 mb-3">
                  Zero Trust Rule Verification Trace
                </h4>
                <div className="space-y-2.5">
                  {evaluation.stepDetails.map((step, idx) => (
                    <div
                      key={idx}
                      className="flex items-start gap-2.5 text-xs p-2.5 rounded border border-slate-800/80 bg-slate-900/50"
                    >
                      {step.passed ? (
                        <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                      ) : (
                        <XCircle className="h-4 w-4 text-rose-400 shrink-0 mt-0.5" />
                      )}
                      <div className="flex-1">
                        <div className="font-semibold text-slate-200">{step.ruleName}</div>
                        <div className="text-slate-400 mt-0.5">{step.detail}</div>
                      </div>
                      <span
                        className={`text-xs font-mono px-2 py-0.5 rounded ${
                          step.passed
                            ? 'bg-emerald-500/10 text-emerald-400'
                            : 'bg-rose-500/10 text-rose-400'
                        }`}
                      >
                        {step.passed ? 'PASSED' : 'FAILED'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-slate-800 px-5 py-3 bg-slate-950/60 flex items-center justify-between text-xs text-slate-400">
          <span>Engine: Aegis Policy Decision Point (PDP) v3.4</span>
          <button
            onClick={() => setIsPolicySandboxOpen(false)}
            className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium"
          >
            Close Sandbox
          </button>
        </div>
      </div>
    </div>
  );
};
