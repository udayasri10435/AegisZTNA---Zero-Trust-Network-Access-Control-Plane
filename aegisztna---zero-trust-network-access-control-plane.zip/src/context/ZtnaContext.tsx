import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  ApplicationResource,
  DevicePosture,
  AccessPolicy,
  EdgeGateway,
  AccessAuditLog,
  JitAccessRequest,
  ClientDaemonState,
  DiskEncryptionStatus,
  EdrStatus
} from '../types/ztna';
import {
  INITIAL_APPLICATIONS,
  INITIAL_DEVICES,
  INITIAL_POLICIES,
  INITIAL_GATEWAYS,
  INITIAL_AUDIT_LOGS,
  INITIAL_JIT_REQUESTS
} from '../data/mockZtnaData';

export interface EvaluationResult {
  decision: 'ALLOW' | 'DENIED' | 'MFA_CHALLENGE' | 'QUARANTINE';
  matchedPolicy: AccessPolicy | null;
  reasons: string[];
  stepDetails: {
    ruleName: string;
    passed: boolean;
    detail: string;
  }[];
}

interface ZtnaContextType {
  applications: ApplicationResource[];
  devices: DevicePosture[];
  policies: AccessPolicy[];
  gateways: EdgeGateway[];
  auditLogs: AccessAuditLog[];
  jitRequests: JitAccessRequest[];
  clientDaemon: ClientDaemonState;
  selectedDeviceForDaemon: DevicePosture;
  setSelectedDeviceForDaemon: (device: DevicePosture) => void;
  toggleDaemonConnection: () => void;
  setClientOverride: (key: 'overrideDiskEncryption' | 'overrideEdrStatus' | 'overrideFirewall', value: any) => void;
  resetClientOverrides: () => void;
  evaluateAccess: (
    userEmail: string,
    deviceId: string,
    resourceId: string,
    customOverrides?: Partial<ClientDaemonState>
  ) => EvaluationResult;
  testAndLogAccess: (resourceId: string) => Promise<EvaluationResult>;
  addApplication: (app: Omit<ApplicationResource, 'id'>) => void;
  updateApplication: (id: string, updates: Partial<ApplicationResource>) => void;
  deleteApplication: (id: string) => void;
  addPolicy: (policy: Omit<AccessPolicy, 'id'>) => void;
  updatePolicy: (id: string, updates: Partial<AccessPolicy>) => void;
  togglePolicy: (id: string) => void;
  deletePolicy: (id: string) => void;
  reorderPolicies: (startIndex: number, endIndex: number) => void;
  quarantineDevice: (deviceId: string, reason: string) => void;
  unquarantineDevice: (deviceId: string) => void;
  triggerDeviceScan: (deviceId: string) => void;
  createJitRequest: (resourceId: string, durationMinutes: number, reason: string) => void;
  approveJitRequest: (requestId: string) => void;
  rejectJitRequest: (requestId: string) => void;
  activeAppModal: ApplicationResource | null;
  setActiveAppModal: (app: ApplicationResource | null) => void;
  activeDeviceModal: DevicePosture | null;
  setActiveDeviceModal: (device: DevicePosture | null) => void;
  activePolicyModal: AccessPolicy | null;
  setActivePolicyModal: (policy: AccessPolicy | null) => void;
  isDaemonModalOpen: boolean;
  setIsDaemonModalOpen: (open: boolean) => void;
  isPolicySandboxOpen: boolean;
  setIsPolicySandboxOpen: (open: boolean) => void;
  isJitModalOpen: boolean;
  setIsJitModalOpen: (open: boolean) => void;
}

const ZtnaContext = createContext<ZtnaContextType | undefined>(undefined);

export const ZtnaProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [applications, setApplications] = useState<ApplicationResource[]>(INITIAL_APPLICATIONS);
  const [devices, setDevices] = useState<DevicePosture[]>(INITIAL_DEVICES);
  const [policies, setPolicies] = useState<AccessPolicy[]>(INITIAL_POLICIES);
  const [gateways] = useState<EdgeGateway[]>(INITIAL_GATEWAYS);
  const [auditLogs, setAuditLogs] = useState<AccessAuditLog[]>(INITIAL_AUDIT_LOGS);
  const [jitRequests, setJitRequests] = useState<JitAccessRequest[]>(INITIAL_JIT_REQUESTS);

  // Active daemon simulated device (defaults to Marcus Vance's MacBook)
  const [selectedDeviceForDaemon, setSelectedDeviceForDaemon] = useState<DevicePosture>(INITIAL_DEVICES[0]);

  // Client daemon state
  const [clientDaemon, setClientDaemon] = useState<ClientDaemonState>({
    connected: true,
    connectedPop: 'IAD-01 (Virginia US)',
    assignedVirtualIp: '100.64.14.82',
    bytesReceived: 84210940,
    bytesTransmitted: 23190840,
    tunnelLatencyMs: 12
  });

  // Modals
  const [activeAppModal, setActiveAppModal] = useState<ApplicationResource | null>(null);
  const [activeDeviceModal, setActiveDeviceModal] = useState<DevicePosture | null>(null);
  const [activePolicyModal, setActivePolicyModal] = useState<AccessPolicy | null>(null);
  const [isDaemonModalOpen, setIsDaemonModalOpen] = useState(false);
  const [isPolicySandboxOpen, setIsPolicySandboxOpen] = useState(false);
  const [isJitModalOpen, setIsJitModalOpen] = useState(false);

  // Sync virtual IP if selected device changes
  useEffect(() => {
    setClientDaemon(prev => ({
      ...prev,
      assignedVirtualIp: selectedDeviceForDaemon.virtualIp
    }));
  }, [selectedDeviceForDaemon]);

  // Simulate background WireGuard keepalive & byte transfer
  useEffect(() => {
    if (!clientDaemon.connected) return;
    const interval = setInterval(() => {
      setClientDaemon(prev => ({
        ...prev,
        bytesReceived: prev.bytesReceived + Math.floor(Math.random() * 8500) + 1200,
        bytesTransmitted: prev.bytesTransmitted + Math.floor(Math.random() * 2400) + 400,
        tunnelLatencyMs: Math.max(9, Math.min(28, prev.tunnelLatencyMs + Math.floor((Math.random() - 0.5) * 4)))
      }));
    }, 4000);
    return () => clearInterval(interval);
  }, [clientDaemon.connected]);

  const toggleDaemonConnection = () => {
    setClientDaemon(prev => ({
      ...prev,
      connected: !prev.connected
    }));
  };

  const setClientOverride = (
    key: 'overrideDiskEncryption' | 'overrideEdrStatus' | 'overrideFirewall',
    value: any
  ) => {
    setClientDaemon(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const resetClientOverrides = () => {
    setClientDaemon(prev => ({
      ...prev,
      overrideDiskEncryption: undefined,
      overrideEdrStatus: undefined,
      overrideFirewall: undefined,
      overrideLocation: undefined
    }));
  };

  // The Core Zero Trust Policy Evaluation Engine
  const evaluateAccess = (
    userEmail: string,
    deviceId: string,
    resourceId: string,
    customOverrides?: Partial<ClientDaemonState>
  ): EvaluationResult => {
    const targetApp = applications.find(a => a.id === resourceId);
    const targetDev = devices.find(d => d.id === deviceId);

    if (!targetApp) {
      return {
        decision: 'DENIED',
        matchedPolicy: null,
        reasons: ['Target application resource not found in directory'],
        stepDetails: [{ ruleName: 'Catalog Lookup', passed: false, detail: 'Resource ID invalid' }]
      };
    }

    if (!targetDev) {
      return {
        decision: 'DENIED',
        matchedPolicy: null,
        reasons: ['Device not registered with enterprise ZTNA posture agent'],
        stepDetails: [{ ruleName: 'Device Certificate', passed: false, detail: 'Unenrolled endpoint' }]
      };
    }

    // Check device posture with any active test overrides
    const effectiveDiskEncryption =
      customOverrides?.overrideDiskEncryption !== undefined
        ? customOverrides.overrideDiskEncryption
        : targetDev.diskEncryption;

    const effectiveEdrStatus =
      customOverrides?.overrideEdrStatus !== undefined
        ? customOverrides.overrideEdrStatus
        : targetDev.edrStatus;

    const effectiveFirewall =
      customOverrides?.overrideFirewall !== undefined
        ? customOverrides.overrideFirewall
        : targetDev.firewallActive;

    // Check if device is quarantined administratively
    if (targetDev.trustLevel === 'quarantined' && !customOverrides) {
      return {
        decision: 'QUARANTINE',
        matchedPolicy: null,
        reasons: [
          `Device is in quarantine: ${targetDev.quarantineReason || 'Administrative isolation'}`
        ],
        stepDetails: [
          {
            ruleName: 'Device Isolation Status',
            passed: false,
            detail: 'Device administratively quarantined. All routes severed.'
          }
        ]
      };
    }

    // Sort active policies by priority (1 is highest priority)
    const sortedPolicies = [...policies]
      .filter(p => p.enabled)
      .sort((a, b) => a.priority - b.priority);

    // Find the first policy that governs this resource
    for (const policy of sortedPolicies) {
      const appliesToResource =
        policy.targetResourceIds.length === 0 || policy.targetResourceIds.includes(resourceId);

      if (!appliesToResource) continue;

      const steps: { ruleName: string; passed: boolean; detail: string }[] = [];
      const failReasons: string[] = [];

      // 1. Identity Check
      const hasMatchingGroup =
        policy.identityConditions.allowedUserGroups.includes(targetDev.userDepartment) ||
        policy.identityConditions.allowedUserGroups.includes(targetDev.userRole);

      if (!hasMatchingGroup) {
        steps.push({
          ruleName: 'Identity & Group Scope',
          passed: false,
          detail: `User department '${targetDev.userDepartment}' not in allowed groups: [${policy.identityConditions.allowedUserGroups.join(', ')}]`
        });
        failReasons.push(`Identity group '${targetDev.userDepartment}' lacks permission`);
        continue; // Try next policy or fail
      } else {
        steps.push({
          ruleName: 'Identity & Group Scope',
          passed: true,
          detail: `User verified: ${targetDev.userName} (${targetDev.userDepartment}) via IdP OIDC`
        });
      }

      // 2. Device Posture: Disk Encryption
      if (policy.deviceConditions.requireDiskEncryption) {
        if (effectiveDiskEncryption !== 'encrypted') {
          steps.push({
            ruleName: 'Full Disk Encryption (FileVault/BitLocker)',
            passed: false,
            detail: `Encryption status is '${effectiveDiskEncryption}' (required: encrypted)`
          });
          failReasons.push('Device disk is not encrypted');
        } else {
          steps.push({
            ruleName: 'Full Disk Encryption',
            passed: true,
            detail: 'Hardware disk encryption validated (XTS-AES 256)'
          });
        }
      }

      // 3. Device Posture: EDR Sensor
      if (policy.deviceConditions.requireEdr) {
        const isEdrAllowed = policy.deviceConditions.allowedEdrAgents.includes(targetDev.edrAgent);
        const isEdrRunning = effectiveEdrStatus === 'running';

        if (!isEdrAllowed || !isEdrRunning) {
          steps.push({
            ruleName: 'EDR Endpoint Protection',
            passed: false,
            detail: `EDR '${targetDev.edrAgent}' status '${effectiveEdrStatus}' (required: active approved sensor)`
          });
          failReasons.push(
            `EDR sensor violation: ${targetDev.edrAgent} is ${effectiveEdrStatus}`
          );
        } else {
          steps.push({
            ruleName: 'EDR Endpoint Protection',
            passed: true,
            detail: `EDR sensor verified: ${targetDev.edrAgent} agent active`
          });
        }
      }

      // 4. Device Posture: Host Firewall
      if (policy.deviceConditions.requireFirewall) {
        if (!effectiveFirewall) {
          steps.push({
            ruleName: 'Host Application Firewall',
            passed: false,
            detail: 'Host OS firewall is disabled'
          });
          failReasons.push('Host application firewall is disabled');
        } else {
          steps.push({
            ruleName: 'Host Application Firewall',
            passed: true,
            detail: 'OS packet filter / firewall active'
          });
        }
      }

      // 5. Geolocation / Country
      if (policy.deviceConditions.allowedCountries.length > 0) {
        const devCountry = targetDev.geolocation.countryCode;
        if (!policy.deviceConditions.allowedCountries.includes(devCountry)) {
          steps.push({
            ruleName: 'Geo-fence IP Validation',
            passed: false,
            detail: `Connecting from ${devCountry}, but policy restricts to [${policy.deviceConditions.allowedCountries.join(', ')}]`
          });
          failReasons.push(`Access from country '${devCountry}' is blocked by geofence`);
        } else {
          steps.push({
            ruleName: 'Geo-fence IP Validation',
            passed: true,
            detail: `Egress IP originates from allowed territory: ${devCountry} (${targetDev.geolocation.city})`
          });
        }
      }

      // If any posture rule failed
      if (failReasons.length > 0) {
        return {
          decision: 'DENIED',
          matchedPolicy: policy,
          reasons: failReasons,
          stepDetails: steps
        };
      }

      // If policy matched and all posture passed:
      const finalDecision =
        policy.action === 'STEP_UP_MFA' || targetApp.mfaRequired
          ? 'MFA_CHALLENGE'
          : 'ALLOW';

      return {
        decision: finalDecision,
        matchedPolicy: policy,
        reasons:
          finalDecision === 'MFA_CHALLENGE'
            ? ['All posture rules passed; Step-up MFA (FIDO2 WebAuthn) required']
            : ['All identity and posture checks passed successfully'],
        stepDetails: steps
      };
    }

    // Default Deny if no policy explicitly allowed
    return {
      decision: 'DENIED',
      matchedPolicy: null,
      reasons: ['Implicit Zero Trust Deny: No explicit policy rule permits this access request'],
      stepDetails: [
        {
          ruleName: 'Default Deny Postulate',
          passed: false,
          detail: 'Zero Trust architecture enforces default-deny for unmapped routes.'
        }
      ]
    };
  };

  // Test an app launch from the simulated client daemon
  const testAndLogAccess = async (resourceId: string): Promise<EvaluationResult> => {
    const targetApp = applications.find(a => a.id === resourceId);
    const overrides: Partial<ClientDaemonState> = {
      overrideDiskEncryption: clientDaemon.overrideDiskEncryption,
      overrideEdrStatus: clientDaemon.overrideEdrStatus,
      overrideFirewall: clientDaemon.overrideFirewall
    };

    const result = evaluateAccess(
      selectedDeviceForDaemon.userEmail,
      selectedDeviceForDaemon.id,
      resourceId,
      overrides
    );

    // Record into audit log
    const newLog: AccessAuditLog = {
      id: `log-${Date.now().toString().slice(-4)}`,
      timestamp: new Date().toISOString(),
      userEmail: selectedDeviceForDaemon.userEmail,
      userName: selectedDeviceForDaemon.userName,
      deviceName: selectedDeviceForDaemon.deviceName,
      resourceId: resourceId,
      resourceName: targetApp ? targetApp.name : 'Unknown Target',
      evaluatedPolicyId: result.matchedPolicy?.id || 'none',
      evaluatedPolicyName: result.matchedPolicy?.name || 'Implicit Default Deny',
      decision: result.decision,
      reasons: result.reasons,
      clientVirtualIp: clientDaemon.assignedVirtualIp,
      edgePop: clientDaemon.connectedPop.slice(0, 6).trim(),
      latencyMs: clientDaemon.tunnelLatencyMs,
      protocol: targetApp ? `${targetApp.protocol}:${targetApp.allowedPorts[0]}` : 'TCP'
    };

    setAuditLogs(prev => [newLog, ...prev.slice(0, 99)]);
    return result;
  };

  const addApplication = (app: Omit<ApplicationResource, 'id'>) => {
    const newApp: ApplicationResource = {
      ...app,
      id: `app-${Date.now().toString().slice(-5)}`
    };
    setApplications(prev => [newApp, ...prev]);
  };

  const updateApplication = (id: string, updates: Partial<ApplicationResource>) => {
    setApplications(prev =>
      prev.map(app => (app.id === id ? { ...app, ...updates } : app))
    );
  };

  const deleteApplication = (id: string) => {
    setApplications(prev => prev.filter(app => app.id !== id));
  };

  const addPolicy = (policy: Omit<AccessPolicy, 'id'>) => {
    const newPol: AccessPolicy = {
      ...policy,
      id: `pol-${Date.now().toString().slice(-5)}`
    };
    setPolicies(prev => [...prev, newPol]);
  };

  const updatePolicy = (id: string, updates: Partial<AccessPolicy>) => {
    setPolicies(prev =>
      prev.map(pol => (pol.id === id ? { ...pol, ...updates } : pol))
    );
  };

  const togglePolicy = (id: string) => {
    setPolicies(prev =>
      prev.map(pol => (pol.id === id ? { ...pol, enabled: !pol.enabled } : pol))
    );
  };

  const deletePolicy = (id: string) => {
    setPolicies(prev => prev.filter(pol => pol.id !== id));
  };

  const reorderPolicies = (startIndex: number, endIndex: number) => {
    setPolicies(prev => {
      const result = Array.from(prev);
      const [removed] = result.splice(startIndex, 1);
      result.splice(endIndex, 0, removed);
      // Re-assign priorities
      return result.map((item, index) => ({
        ...item,
        priority: index + 1
      }));
    });
  };

  const quarantineDevice = (deviceId: string, reason: string) => {
    setDevices(prev =>
      prev.map(dev =>
        dev.id === deviceId
          ? {
              ...dev,
              trustLevel: 'quarantined',
              quarantineReason: reason,
              lastPostureCheckAt: new Date().toISOString()
            }
          : dev
      )
    );
  };

  const unquarantineDevice = (deviceId: string) => {
    setDevices(prev =>
      prev.map(dev =>
        dev.id === deviceId
          ? {
              ...dev,
              trustLevel: 'compliant',
              quarantineReason: undefined,
              lastPostureCheckAt: new Date().toISOString()
            }
          : dev
      )
    );
  };

  const triggerDeviceScan = (deviceId: string) => {
    setDevices(prev =>
      prev.map(dev => {
        if (dev.id !== deviceId) return dev;
        // recalculate trust level based on state
        const isCompliant =
          dev.diskEncryption === 'encrypted' &&
          dev.edrStatus === 'running' &&
          dev.firewallActive;
        return {
          ...dev,
          trustLevel: isCompliant ? 'compliant' : dev.firewallActive ? 'warning' : 'quarantined',
          lastPostureCheckAt: new Date().toISOString()
        };
      })
    );
  };

  const createJitRequest = (resourceId: string, durationMinutes: number, reason: string) => {
    const targetApp = applications.find(a => a.id === resourceId);
    const newReq: JitAccessRequest = {
      id: `jit-${Date.now().toString().slice(-4)}`,
      userEmail: selectedDeviceForDaemon.userEmail,
      userName: selectedDeviceForDaemon.userName,
      resourceId,
      resourceName: targetApp?.name || 'Resource',
      durationMinutes,
      reason,
      status: 'pending',
      requestedAt: new Date().toISOString()
    };
    setJitRequests(prev => [newReq, ...prev]);
  };

  const approveJitRequest = (requestId: string) => {
    setJitRequests(prev =>
      prev.map(req => {
        if (req.id !== requestId) return req;
        const now = new Date();
        const expires = new Date(now.getTime() + req.durationMinutes * 60 * 1000);
        return {
          ...req,
          status: 'approved',
          approvedAt: now.toISOString(),
          expiresAt: expires.toISOString()
        };
      })
    );
  };

  const rejectJitRequest = (requestId: string) => {
    setJitRequests(prev =>
      prev.map(req => (req.id === requestId ? { ...req, status: 'rejected' } : req))
    );
  };

  return (
    <ZtnaContext.Provider
      value={{
        applications,
        devices,
        policies,
        gateways,
        auditLogs,
        jitRequests,
        clientDaemon,
        selectedDeviceForDaemon,
        setSelectedDeviceForDaemon,
        toggleDaemonConnection,
        setClientOverride,
        resetClientOverrides,
        evaluateAccess,
        testAndLogAccess,
        addApplication,
        updateApplication,
        deleteApplication,
        addPolicy,
        updatePolicy,
        togglePolicy,
        deletePolicy,
        reorderPolicies,
        quarantineDevice,
        unquarantineDevice,
        triggerDeviceScan,
        createJitRequest,
        approveJitRequest,
        rejectJitRequest,
        activeAppModal,
        setActiveAppModal,
        activeDeviceModal,
        setActiveDeviceModal,
        activePolicyModal,
        setActivePolicyModal,
        isDaemonModalOpen,
        setIsDaemonModalOpen,
        isPolicySandboxOpen,
        setIsPolicySandboxOpen,
        isJitModalOpen,
        setIsJitModalOpen
      }}
    >
      {children}
    </ZtnaContext.Provider>
  );
};

export const useZtna = () => {
  const context = useContext(ZtnaContext);
  if (!context) {
    throw new Error('useZtna must be used within a ZtnaProvider');
  }
  return context;
};
