export type OsType = 'macOS' | 'Windows 11' | 'Ubuntu Linux' | 'iOS' | 'Android';

export type DiskEncryptionStatus = 'encrypted' | 'disabled' | 'encrypting';
export type EdrAgentType = 'crowdstrike' | 'sentinelone' | 'defender' | 'none';
export type EdrStatus = 'running' | 'outdated' | 'stopped' | 'not_installed';
export type PostureTrustLevel = 'compliant' | 'warning' | 'quarantined';

export interface DevicePosture {
  id: string;
  deviceName: string;
  userEmail: string;
  userName: string;
  userRole: string;
  userDepartment: string;
  osType: OsType;
  osVersion: string;
  serialNumber: string;
  tpmEnclaveEnabled: boolean;
  diskEncryption: DiskEncryptionStatus;
  edrAgent: EdrAgentType;
  edrStatus: EdrStatus;
  firewallActive: boolean;
  screenLockTimeoutMin: number;
  jailbroken: boolean;
  virtualIp: string;
  lastPostureCheckAt: string;
  trustLevel: PostureTrustLevel;
  quarantineReason?: string;
  geolocation: {
    city: string;
    country: string;
    countryCode: string;
    ip: string;
  };
}

export type AppCategory = 'web_internal' | 'database' | 'bastion_ssh' | 'kubernetes' | 'saas_sso' | 'rdp';
export type AppProtocol = 'HTTPS' | 'TCP' | 'SSH' | 'K8S' | 'RDP';

export interface ApplicationResource {
  id: string;
  name: string;
  slug: string;
  description: string;
  category: AppCategory;
  internalUri: string;
  publicFqdn: string;
  gatewayId: string;
  allowedPorts: number[];
  protocol: AppProtocol;
  posturePolicyProfile: 'strict_prod' | 'corp_standard' | 'contractor_limited';
  mfaRequired: boolean;
  activeSessionsCount: number;
  healthStatus: 'healthy' | 'degraded' | 'offline';
  avgLatencyMs: number;
  tags: string[];
}

export interface AccessPolicy {
  id: string;
  priority: number;
  name: string;
  description: string;
  enabled: boolean;
  identityConditions: {
    allowedUserGroups: string[];
    allowedDepartments?: string[];
  };
  deviceConditions: {
    minOsVersions?: Partial<Record<OsType, string>>;
    requireDiskEncryption: boolean;
    requireEdr: boolean;
    allowedEdrAgents: EdrAgentType[];
    requireFirewall: boolean;
    maxScreenLockMin: number;
    disallowJailbreak: boolean;
    allowedCountries: string[];
  };
  targetResourceIds: string[]; // empty means all or mapped
  action: 'ALLOW' | 'STEP_UP_MFA' | 'QUARANTINE_BLOCK' | 'ISOLATE_RECORD';
  createdAt: string;
}

export interface AccessAuditLog {
  id: string;
  timestamp: string;
  userEmail: string;
  userName: string;
  deviceName: string;
  resourceId: string;
  resourceName: string;
  evaluatedPolicyId: string;
  evaluatedPolicyName: string;
  decision: 'ALLOW' | 'DENIED' | 'MFA_CHALLENGE' | 'QUARANTINE';
  reasons: string[];
  clientVirtualIp: string;
  edgePop: string;
  latencyMs: number;
  protocol: string;
}

export interface EdgeGateway {
  id: string;
  name: string;
  region: string;
  popCode: string;
  provider: 'aws' | 'gcp' | 'azure' | 'on_prem';
  publicIp: string;
  wireguardEndpoint: string;
  tunnelsActive: number;
  throughputMbps: number;
  status: 'online' | 'degraded' | 'maintenance';
  uptimePercentage: number;
}

export interface JitAccessRequest {
  id: string;
  userEmail: string;
  userName: string;
  resourceId: string;
  resourceName: string;
  durationMinutes: number;
  reason: string;
  status: 'pending' | 'approved' | 'rejected' | 'expired';
  requestedAt: string;
  approvedAt?: string;
  expiresAt?: string;
}

export interface ClientDaemonState {
  connected: boolean;
  connectedPop: string;
  assignedVirtualIp: string;
  bytesReceived: number;
  bytesTransmitted: number;
  tunnelLatencyMs: number;
  // Overrides to test posture live on the client simulator
  overrideDiskEncryption?: DiskEncryptionStatus;
  overrideEdrStatus?: EdrStatus;
  overrideFirewall?: boolean;
  overrideLocation?: {
    city: string;
    country: string;
    countryCode: string;
  };
}
