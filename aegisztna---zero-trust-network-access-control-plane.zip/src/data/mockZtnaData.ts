import {
  DevicePosture,
  ApplicationResource,
  AccessPolicy,
  EdgeGateway,
  AccessAuditLog,
  JitAccessRequest
} from '../types/ztna';

export const INITIAL_GATEWAYS: EdgeGateway[] = [
  {
    id: 'gw-iad-01',
    name: 'US-East AWS Connector',
    region: 'North Virginia (us-east-1)',
    popCode: 'IAD-01',
    provider: 'aws',
    publicIp: '54.210.14.92',
    wireguardEndpoint: 'iad01.mesh.aegis-ztna.net:51820',
    tunnelsActive: 142,
    throughputMbps: 684.2,
    status: 'online',
    uptimePercentage: 99.99
  },
  {
    id: 'gw-fra-02',
    name: 'EU-Central GCP Connector',
    region: 'Frankfurt (europe-west3)',
    popCode: 'FRA-02',
    provider: 'gcp',
    publicIp: '34.141.88.11',
    wireguardEndpoint: 'fra02.mesh.aegis-ztna.net:51820',
    tunnelsActive: 89,
    throughputMbps: 412.0,
    status: 'online',
    uptimePercentage: 99.98
  },
  {
    id: 'gw-nrt-01',
    name: 'APAC-Tokyo Cloud Edge',
    region: 'Tokyo (ap-northeast-1)',
    popCode: 'NRT-01',
    provider: 'aws',
    publicIp: '13.230.104.55',
    wireguardEndpoint: 'nrt01.mesh.aegis-ztna.net:51820',
    tunnelsActive: 64,
    throughputMbps: 295.4,
    status: 'online',
    uptimePercentage: 100.0
  },
  {
    id: 'gw-atx-dc',
    name: 'Austin Enterprise Datacenter',
    region: 'Texas On-Premise Core',
    popCode: 'ATX-01',
    provider: 'on_prem',
    publicIp: '198.51.100.24',
    wireguardEndpoint: 'atx-gw.corp.internal:51820',
    tunnelsActive: 118,
    throughputMbps: 840.1,
    status: 'online',
    uptimePercentage: 99.95
  }
];

export const INITIAL_APPLICATIONS: ApplicationResource[] = [
  {
    id: 'app-pg-prod',
    name: 'Production PostgreSQL Cluster',
    slug: 'prod-postgres-db',
    description: 'Primary customer relational database cluster hosted in AWS VPC private subnet',
    category: 'database',
    internalUri: 'postgres://db-prod.internal.vpc:5432/aegis_core',
    publicFqdn: 'db.prod.aegis-mesh.internal',
    gatewayId: 'gw-iad-01',
    allowedPorts: [5432],
    protocol: 'TCP',
    posturePolicyProfile: 'strict_prod',
    mfaRequired: true,
    activeSessionsCount: 14,
    healthStatus: 'healthy',
    avgLatencyMs: 12,
    tags: ['pci-dss', 'production', 'tier-0']
  },
  {
    id: 'app-k8s-prod',
    name: 'Production Kubernetes API (EKS)',
    slug: 'prod-k8s-control-plane',
    description: 'Zero Trust protected control plane endpoint for production microservices',
    category: 'kubernetes',
    internalUri: 'https://k8s-api.prod.vpc:6443',
    publicFqdn: 'k8s.control.aegis-mesh.internal',
    gatewayId: 'gw-iad-01',
    allowedPorts: [6443],
    protocol: 'K8S',
    posturePolicyProfile: 'strict_prod',
    mfaRequired: true,
    activeSessionsCount: 28,
    healthStatus: 'healthy',
    avgLatencyMs: 14,
    tags: ['infrastructure', 'kubernetes', 'prod']
  },
  {
    id: 'app-gitlab',
    name: 'Internal GitLab & Container Registry',
    slug: 'corp-gitlab',
    description: 'Self-hosted source code repository and private Docker registry',
    category: 'web_internal',
    internalUri: 'https://gitlab.corp.local',
    publicFqdn: 'gitlab.aegis-mesh.internal',
    gatewayId: 'gw-fra-02',
    allowedPorts: [443, 22],
    protocol: 'HTTPS',
    posturePolicyProfile: 'corp_standard',
    mfaRequired: false,
    activeSessionsCount: 52,
    healthStatus: 'healthy',
    avgLatencyMs: 19,
    tags: ['engineering', 'web-app', 'developer-tools']
  },
  {
    id: 'app-grafana',
    name: 'SecOps Telemetry & Observability',
    slug: 'secops-grafana',
    description: 'Internal Prometheus & Loki telemetry dashboards for SIEM monitoring',
    category: 'web_internal',
    internalUri: 'https://telemetry.internal:3000',
    publicFqdn: 'grafana.aegis-mesh.internal',
    gatewayId: 'gw-iad-01',
    allowedPorts: [3000, 443],
    protocol: 'HTTPS',
    posturePolicyProfile: 'corp_standard',
    mfaRequired: false,
    activeSessionsCount: 39,
    healthStatus: 'healthy',
    avgLatencyMs: 16,
    tags: ['monitoring', 'observability']
  },
  {
    id: 'app-ssh-bastion',
    name: 'PCI-DSS Payment Bastion',
    slug: 'payment-enclave-ssh',
    description: 'Hardware token authenticated SSH gateway into PCI credit card tokenization zone',
    category: 'bastion_ssh',
    internalUri: 'ssh://bastion.pci.internal:22',
    publicFqdn: 'bastion.pci.aegis-mesh.internal',
    gatewayId: 'gw-atx-dc',
    allowedPorts: [22],
    protocol: 'SSH',
    posturePolicyProfile: 'strict_prod',
    mfaRequired: true,
    activeSessionsCount: 3,
    healthStatus: 'healthy',
    avgLatencyMs: 24,
    tags: ['pci-scope', 'bastion', 'restricted']
  },
  {
    id: 'app-billing-api',
    name: 'Billing Admin Console',
    slug: 'internal-billing-ui',
    description: 'Customer subscription management and refund processing portal',
    category: 'web_internal',
    internalUri: 'https://billing-admin.corp:8443',
    publicFqdn: 'billing.aegis-mesh.internal',
    gatewayId: 'gw-iad-01',
    allowedPorts: [8443],
    protocol: 'HTTPS',
    posturePolicyProfile: 'corp_standard',
    mfaRequired: true,
    activeSessionsCount: 17,
    healthStatus: 'healthy',
    avgLatencyMs: 15,
    tags: ['finance', 'operations']
  },
  {
    id: 'app-staging-redis',
    name: 'Staging Redis Cluster',
    slug: 'staging-redis-cache',
    description: 'Shared memory cache for staging environment tests',
    category: 'database',
    internalUri: 'redis://redis-stage.vpc:6379',
    publicFqdn: 'redis.staging.aegis-mesh.internal',
    gatewayId: 'gw-nrt-01',
    allowedPorts: [6379],
    protocol: 'TCP',
    posturePolicyProfile: 'contractor_limited',
    mfaRequired: false,
    activeSessionsCount: 8,
    healthStatus: 'healthy',
    avgLatencyMs: 31,
    tags: ['staging', 'cache']
  },
  {
    id: 'app-dc-rdp',
    name: 'Austin DC Windows Admin RDP',
    slug: 'onprem-windows-rdp',
    description: 'Direct encapsulated RDP session to on-prem domain controller management host',
    category: 'rdp',
    internalUri: 'rdp://ad-admin.dc.local:3389',
    publicFqdn: 'dc-admin.aegis-mesh.internal',
    gatewayId: 'gw-atx-dc',
    allowedPorts: [3389],
    protocol: 'RDP',
    posturePolicyProfile: 'strict_prod',
    mfaRequired: true,
    activeSessionsCount: 2,
    healthStatus: 'healthy',
    avgLatencyMs: 28,
    tags: ['active-directory', 'on-prem']
  }
];

export const INITIAL_DEVICES: DevicePosture[] = [
  {
    id: 'dev-mv-mac',
    deviceName: "Marcus Vance's MacBook Pro 16\"",
    userEmail: 'marcus.vance@company.com',
    userName: 'Marcus Vance',
    userRole: 'Staff Security Engineer',
    userDepartment: 'SecOps',
    osType: 'macOS',
    osVersion: 'Sonoma 14.5.0',
    serialNumber: 'C02GK993MD6R',
    tpmEnclaveEnabled: true,
    diskEncryption: 'encrypted',
    edrAgent: 'crowdstrike',
    edrStatus: 'running',
    firewallActive: true,
    screenLockTimeoutMin: 5,
    jailbroken: false,
    virtualIp: '100.64.14.82',
    lastPostureCheckAt: new Date(Date.now() - 45 * 1000).toISOString(),
    trustLevel: 'compliant',
    geolocation: {
      city: 'Ashburn',
      country: 'United States',
      countryCode: 'US',
      ip: '72.14.201.8'
    }
  },
  {
    id: 'dev-er-win',
    deviceName: "Elena Rostova's ThinkPad X1 Carbon",
    userEmail: 'elena.rostova@company.com',
    userName: 'Elena Rostova',
    userRole: 'SRE Lead Architect',
    userDepartment: 'Infrastructure',
    osType: 'Windows 11',
    osVersion: '23H2 (Build 22631)',
    serialNumber: 'PF38Z109Q',
    tpmEnclaveEnabled: true,
    diskEncryption: 'encrypted',
    edrAgent: 'defender',
    edrStatus: 'running',
    firewallActive: true,
    screenLockTimeoutMin: 5,
    jailbroken: false,
    virtualIp: '100.64.14.93',
    lastPostureCheckAt: new Date(Date.now() - 110 * 1000).toISOString(),
    trustLevel: 'compliant',
    geolocation: {
      city: 'Berlin',
      country: 'Germany',
      countryCode: 'DE',
      ip: '88.198.41.92'
    }
  },
  {
    id: 'dev-ac-mac',
    deviceName: "Alice Chen's MacBook Air M2",
    userEmail: 'alice.chen@company.com',
    userName: 'Alice Chen',
    userRole: 'Senior Backend Engineer',
    userDepartment: 'Engineering',
    osType: 'macOS',
    osVersion: 'Sonoma 14.3.1',
    serialNumber: 'FVFGQ811Q6L4',
    tpmEnclaveEnabled: true,
    diskEncryption: 'encrypted',
    edrAgent: 'sentinelone',
    edrStatus: 'running',
    firewallActive: false, // Warning posture!
    screenLockTimeoutMin: 15,
    jailbroken: false,
    virtualIp: '100.64.14.104',
    lastPostureCheckAt: new Date(Date.now() - 180 * 1000).toISOString(),
    trustLevel: 'warning',
    quarantineReason: 'macOS Application Firewall is disabled in System Settings.',
    geolocation: {
      city: 'San Francisco',
      country: 'United States',
      countryCode: 'US',
      ip: '67.180.12.190'
    }
  },
  {
    id: 'dev-lo-linux',
    deviceName: "Liam O'Connor's Dell XPS Developer Edition",
    userEmail: 'liam.oconnor@company.com',
    userName: "Liam O'Connor",
    userRole: 'Cloud Infrastructure DevOps',
    userDepartment: 'Infrastructure',
    osType: 'Ubuntu Linux',
    osVersion: '24.04 LTS (Noble Numbat)',
    serialNumber: '89HKP23',
    tpmEnclaveEnabled: true,
    diskEncryption: 'encrypted',
    edrAgent: 'sentinelone',
    edrStatus: 'running',
    firewallActive: true,
    screenLockTimeoutMin: 5,
    jailbroken: false,
    virtualIp: '100.64.14.119',
    lastPostureCheckAt: new Date(Date.now() - 95 * 1000).toISOString(),
    trustLevel: 'compliant',
    geolocation: {
      city: 'Dublin',
      country: 'Ireland',
      countryCode: 'IE',
      ip: '185.124.78.33'
    }
  },
  {
    id: 'dev-qa-contractor',
    deviceName: "Apex QA Contractor Laptop (BYOD)",
    userEmail: 's.patel.ext@apex-qa.vendor.net',
    userName: 'Siddharth Patel (Contractor)',
    userRole: 'QA Test Automation Lead',
    userDepartment: 'Contractors',
    osType: 'Windows 11',
    osVersion: '21H2 (Deprecated)',
    serialNumber: 'DESKTOP-8N2M9Q',
    tpmEnclaveEnabled: false,
    diskEncryption: 'disabled', // Fails encryption check!
    edrAgent: 'none',
    edrStatus: 'not_installed', // Fails EDR check!
    firewallActive: false,
    screenLockTimeoutMin: 30,
    jailbroken: false,
    virtualIp: '100.64.14.240',
    lastPostureCheckAt: new Date(Date.now() - 400 * 1000).toISOString(),
    trustLevel: 'quarantined',
    quarantineReason: 'Multiple policy violations: BitLocker not active, missing corporate EDR sensor, outdated OS build.',
    geolocation: {
      city: 'Bengaluru',
      country: 'India',
      countryCode: 'IN',
      ip: '103.22.44.89'
    }
  },
  {
    id: 'dev-vp-ios',
    deviceName: "Sarah Lindqvist's iPhone 15 Pro",
    userEmail: 'sarah.lindqvist@company.com',
    userName: 'Sarah Lindqvist',
    userRole: 'VP of Engineering',
    userDepartment: 'Executive',
    osType: 'iOS',
    osVersion: '17.5.1',
    serialNumber: 'DX7G9012PQW3',
    tpmEnclaveEnabled: true,
    diskEncryption: 'encrypted',
    edrAgent: 'crowdstrike',
    edrStatus: 'running',
    firewallActive: true,
    screenLockTimeoutMin: 5,
    jailbroken: false,
    virtualIp: '100.64.14.305',
    lastPostureCheckAt: new Date(Date.now() - 60 * 1000).toISOString(),
    trustLevel: 'compliant',
    geolocation: {
      city: 'New York',
      country: 'United States',
      countryCode: 'US',
      ip: '108.35.88.2'
    }
  }
];

export const INITIAL_POLICIES: AccessPolicy[] = [
  {
    id: 'pol-tier0-db',
    priority: 1,
    name: 'Tier-0 Production Database Strict Policy',
    description: 'Enforces hardware enclave, CrowdStrike/SentinelOne EDR, full disk encryption, and step-up MFA for production SQL',
    enabled: true,
    identityConditions: {
      allowedUserGroups: ['SecOps', 'Infrastructure', 'Engineering'],
      allowedDepartments: ['SecOps', 'Infrastructure']
    },
    deviceConditions: {
      requireDiskEncryption: true,
      requireEdr: true,
      allowedEdrAgents: ['crowdstrike', 'sentinelone', 'defender'],
      requireFirewall: true,
      maxScreenLockMin: 10,
      disallowJailbreak: true,
      allowedCountries: ['US', 'DE', 'IE', 'GB', 'CA']
    },
    targetResourceIds: ['app-pg-prod', 'app-k8s-prod'],
    action: 'STEP_UP_MFA',
    createdAt: '2026-01-15T08:00:00Z'
  },
  {
    id: 'pol-pci-bastion',
    priority: 2,
    name: 'PCI Enclave Bastion Zero Trust Access',
    description: 'Strict hardware-bound certificate and verified EDR requirement for SSH Bastion access',
    enabled: true,
    identityConditions: {
      allowedUserGroups: ['SecOps', 'Infrastructure'],
      allowedDepartments: ['SecOps']
    },
    deviceConditions: {
      requireDiskEncryption: true,
      requireEdr: true,
      allowedEdrAgents: ['crowdstrike'],
      requireFirewall: true,
      maxScreenLockMin: 5,
      disallowJailbreak: true,
      allowedCountries: ['US']
    },
    targetResourceIds: ['app-ssh-bastion'],
    action: 'ALLOW',
    createdAt: '2026-02-01T10:30:00Z'
  },
  {
    id: 'pol-general-corp',
    priority: 3,
    name: 'Corporate Internal Web Applications',
    description: 'Standard device compliance policy for GitLab, Observability, and Internal Admin Portals',
    enabled: true,
    identityConditions: {
      allowedUserGroups: ['Engineering', 'Infrastructure', 'SecOps', 'Executive'],
      allowedDepartments: ['Engineering', 'Infrastructure', 'SecOps', 'Executive']
    },
    deviceConditions: {
      requireDiskEncryption: true,
      requireEdr: true,
      allowedEdrAgents: ['crowdstrike', 'sentinelone', 'defender'],
      requireFirewall: true,
      maxScreenLockMin: 15,
      disallowJailbreak: true,
      allowedCountries: ['US', 'DE', 'IE', 'GB', 'CA', 'JP', 'FR']
    },
    targetResourceIds: ['app-gitlab', 'app-grafana', 'app-billing-api'],
    action: 'ALLOW',
    createdAt: '2026-01-10T12:00:00Z'
  },
  {
    id: 'pol-contractor-stage',
    priority: 4,
    name: 'External Contractor Staging Sandbox Policy',
    description: 'Restricted per-app access to isolated staging caches only; blocks all lateral network movement',
    enabled: true,
    identityConditions: {
      allowedUserGroups: ['Contractors', 'Engineering'],
      allowedDepartments: ['Contractors']
    },
    deviceConditions: {
      requireDiskEncryption: true, // Note: Contractor laptop fails this
      requireEdr: false,
      allowedEdrAgents: ['crowdstrike', 'sentinelone', 'defender', 'none'],
      requireFirewall: false,
      maxScreenLockMin: 30,
      disallowJailbreak: true,
      allowedCountries: ['US', 'IN', 'DE', 'IE']
    },
    targetResourceIds: ['app-staging-redis'],
    action: 'ALLOW',
    createdAt: '2026-02-20T14:15:00Z'
  },
  {
    id: 'pol-onprem-dc-rdp',
    priority: 5,
    name: 'On-Prem Datacenter RDP Management',
    description: 'Guards direct Windows Domain Controller RDP session behind strict SecOps validation',
    enabled: true,
    identityConditions: {
      allowedUserGroups: ['Infrastructure', 'SecOps'],
      allowedDepartments: ['Infrastructure']
    },
    deviceConditions: {
      requireDiskEncryption: true,
      requireEdr: true,
      allowedEdrAgents: ['crowdstrike', 'defender'],
      requireFirewall: true,
      maxScreenLockMin: 5,
      disallowJailbreak: true,
      allowedCountries: ['US', 'DE']
    },
    targetResourceIds: ['app-dc-rdp'],
    action: 'STEP_UP_MFA',
    createdAt: '2026-03-01T09:00:00Z'
  }
];

export const INITIAL_AUDIT_LOGS: AccessAuditLog[] = [
  {
    id: 'log-801',
    timestamp: new Date(Date.now() - 2 * 60 * 1000).toISOString(),
    userEmail: 'marcus.vance@company.com',
    userName: 'Marcus Vance',
    deviceName: "Marcus Vance's MacBook Pro 16\"",
    resourceId: 'app-pg-prod',
    resourceName: 'Production PostgreSQL Cluster',
    evaluatedPolicyId: 'pol-tier0-db',
    evaluatedPolicyName: 'Tier-0 Production Database Strict Policy',
    decision: 'ALLOW',
    reasons: ['CrowdStrike Falcon verified healthy', 'FileVault 2 encrypted', 'FIDO2 WebAuthn step-up passed'],
    clientVirtualIp: '100.64.14.82',
    edgePop: 'IAD-01',
    latencyMs: 12,
    protocol: 'TCP:5432'
  },
  {
    id: 'log-802',
    timestamp: new Date(Date.now() - 4 * 60 * 1000).toISOString(),
    userEmail: 'alice.chen@company.com',
    userName: 'Alice Chen',
    deviceName: "Alice Chen's MacBook Air M2",
    resourceId: 'app-pg-prod',
    resourceName: 'Production PostgreSQL Cluster',
    evaluatedPolicyId: 'pol-tier0-db',
    evaluatedPolicyName: 'Tier-0 Production Database Strict Policy',
    decision: 'DENIED',
    reasons: ['Device Posture Failed: Host Application Firewall is disabled'],
    clientVirtualIp: '100.64.14.104',
    edgePop: 'IAD-01',
    latencyMs: 8,
    protocol: 'TCP:5432'
  },
  {
    id: 'log-803',
    timestamp: new Date(Date.now() - 7 * 60 * 1000).toISOString(),
    userEmail: 'elena.rostova@company.com',
    userName: 'Elena Rostova',
    deviceName: "Elena Rostova's ThinkPad X1 Carbon",
    resourceId: 'app-k8s-prod',
    resourceName: 'Production Kubernetes API (EKS)',
    evaluatedPolicyId: 'pol-tier0-db',
    evaluatedPolicyName: 'Tier-0 Production Database Strict Policy',
    decision: 'ALLOW',
    reasons: ['BitLocker XTS-AES 256 compliant', 'Defender ATP running', 'mTLS client handshake valid'],
    clientVirtualIp: '100.64.14.93',
    edgePop: 'FRA-02',
    latencyMs: 14,
    protocol: 'HTTPS:6443'
  },
  {
    id: 'log-804',
    timestamp: new Date(Date.now() - 11 * 60 * 1000).toISOString(),
    userEmail: 's.patel.ext@apex-qa.vendor.net',
    userName: 'Siddharth Patel (Contractor)',
    deviceName: 'Apex QA Contractor Laptop (BYOD)',
    resourceId: 'app-staging-redis',
    resourceName: 'Staging Redis Cluster',
    evaluatedPolicyId: 'pol-contractor-stage',
    evaluatedPolicyName: 'External Contractor Staging Sandbox Policy',
    decision: 'QUARANTINE',
    reasons: [
      'Quarantined: BitLocker full-disk encryption is inactive',
      'Quarantined: No verified enterprise EDR agent present'
    ],
    clientVirtualIp: '100.64.14.240',
    edgePop: 'NRT-01',
    latencyMs: 6,
    protocol: 'TCP:6379'
  },
  {
    id: 'log-805',
    timestamp: new Date(Date.now() - 16 * 60 * 1000).toISOString(),
    userEmail: "liam.oconnor@company.com",
    userName: "Liam O'Connor",
    deviceName: "Liam O'Connor's Dell XPS Developer Edition",
    resourceId: 'app-gitlab',
    resourceName: 'Internal GitLab & Container Registry',
    evaluatedPolicyId: 'pol-general-corp',
    evaluatedPolicyName: 'Corporate Internal Web Applications',
    decision: 'ALLOW',
    reasons: ['LUKS disk encrypted', 'SentinelOne agent version 23.4 active', 'Identity group: Infrastructure'],
    clientVirtualIp: '100.64.14.119',
    edgePop: 'FRA-02',
    latencyMs: 19,
    protocol: 'HTTPS:443'
  },
  {
    id: 'log-806',
    timestamp: new Date(Date.now() - 22 * 60 * 1000).toISOString(),
    userEmail: 'marcus.vance@company.com',
    userName: 'Marcus Vance',
    deviceName: "Marcus Vance's MacBook Pro 16\"",
    resourceId: 'app-ssh-bastion',
    resourceName: 'PCI-DSS Payment Bastion',
    evaluatedPolicyId: 'pol-pci-bastion',
    evaluatedPolicyName: 'PCI Enclave Bastion Zero Trust Access',
    decision: 'ALLOW',
    reasons: ['Hardware enclave YubiKey signed token', 'CrowdStrike Falcon active', 'SecOps role verified'],
    clientVirtualIp: '100.64.14.82',
    edgePop: 'ATX-01',
    latencyMs: 24,
    protocol: 'SSH:22'
  }
];

export const INITIAL_JIT_REQUESTS: JitAccessRequest[] = [
  {
    id: 'jit-101',
    userEmail: 'alice.chen@company.com',
    userName: 'Alice Chen',
    resourceId: 'app-pg-prod',
    resourceName: 'Production PostgreSQL Cluster',
    durationMinutes: 30,
    reason: 'Investigate incident #INC-942 deadlock on payments table',
    status: 'pending',
    requestedAt: new Date(Date.now() - 5 * 60 * 1000).toISOString()
  },
  {
    id: 'jit-102',
    userEmail: 'liam.oconnor@company.com',
    userName: "Liam O'Connor",
    resourceId: 'app-dc-rdp',
    resourceName: 'Austin DC Windows Admin RDP',
    durationMinutes: 60,
    reason: 'Monthly domain controller patch verification and backup audit',
    status: 'approved',
    requestedAt: new Date(Date.now() - 40 * 60 * 1000).toISOString(),
    approvedAt: new Date(Date.now() - 35 * 60 * 1000).toISOString(),
    expiresAt: new Date(Date.now() + 25 * 60 * 1000).toISOString()
  }
];
